<?php
/**
 *
 * @package           PRC_Charting_Library
 * @author            Ben Wormald
 * @copyright         2023 Pew Research Center
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       PRC Charting Library
 * Plugin URI:        https://github.com/pewresearch/pewresearch-org
 * Description:       Pew Research Center's propietary charting library framework for use in PRC Platform.
 * Version:           1.0.0
 * Requires at least: 6.2
 * Requires PHP:      8.0
 * Author:            Ben Wormald
 * Author URI:        https://pewresearch.org
 * Text Domain:       prc-charting-library
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

class PRC_Charting_Library {
	public function __construct( $init = false ) {
		if ( true === $init ) {
			add_action('wp_enqueue_scripts',    array($this, 'init_charting_library_script'), 0);
			add_action('admin_enqueue_scripts', array($this, 'init_charting_library_script'), 0);
		}
	}

	/**
	 * Register first party scripts.
	 * Fires early, on wp_enqueue_scripts.
	 * @return void
	 */
	public function init_charting_library_script() {
        $asset_file  = include(plugin_dir_path( __FILE__ ) . 'build/index.asset.php');
        $script_src  = plugin_dir_url( __FILE__ ) . 'build/index.js';
		// @TODO: Add module support
		// @TODO: We will need to figure out how to convert to preact from react when building the module.
		// $module_asset_file  = include(  plugin_dir_path( __FILE__ )  . 'build/module.min.asset.php' );
		// $module_src  = plugin_dir_url( __FILE__ ) . 'build/module.min.js';

        $script = wp_register_script(
            'prc-charting-library',
            $script_src,
            $asset_file['dependencies'],
            $asset_file['version'],
            true
        );

		// $module = wp_register_script_module(
		// 	prc-charting-library,
		// 	$module_src,
		// 	$module_asset_file['dependencies'],
		// 	$module_asset_file['version'],
		// 	true
		// );

		if ( ! $script ) {
			return new WP_Error( 'prc-charting-library', __( 'Error registering script.' ) );
		}
	}
}

$prc_charting_library = new PRC_Charting_Library(true);
