import {
  ChartBuilderWrapper,
  baseConfig as ChartBuilderBaseConfig,
  ChartBuilderTextWrapper,
  ChartBuilderRenderer,
} from './lib'

function loadScript(slug, script) {
  if (!window.prcChartBuilder[slug]) {
    window.prcChartBuilder[slug] = script
  }
}

window.prcChartBuilder = {}

loadScript('ChartBuilderWrapper', ChartBuilderWrapper)
loadScript('ChartBuilderTextWrapper', ChartBuilderTextWrapper)
loadScript('ChartBuilderBaseConfig', ChartBuilderBaseConfig)
loadScript('ChartBuilderRenderer', ChartBuilderRenderer)

console.log('Loading @prc/chart-builder...', window.prcChartBuilder)

// for module exports??
// export { ChartBuilderWrapper, baseConfig, ChartBuilderTextWrapper, ChartBuilderRenderer }
