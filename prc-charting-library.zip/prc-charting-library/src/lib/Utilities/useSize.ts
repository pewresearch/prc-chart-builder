import { useEffect, useState } from 'react'
import type { Size } from '../ts/types/windowSize'

function useSize(
  className: string | undefined,
  svgRef: React.RefObject<SVGSVGElement>,
): Size {
  const [size, setSize] = useState<Size>({
    width: undefined,
    height: undefined,
  })
  useEffect(() => {
    function handleResize() {
      const element = svgRef.current?.closest(`.${className}`)
      // if no class name is passed, return the window size
      if (element) {
        const { width, height } = element.getBoundingClientRect()
        setSize({ width, height })
        return
      }

      setSize({
        width: window.innerWidth,
        height: window.innerHeight,
      })
    }
    // Add event listener
    window.addEventListener('resize', handleResize)
    // check if there are PRC blocks on the page, and wait for special listener
    // otherwise, wait for window to load
    if (document.querySelector('.wp-block-prc-block-tabs')) {
      window.addEventListener('tabsReady', handleResize)
    } else {
      window.addEventListener('load', handleResize)
    } // set initial size on timeout.
    // This is needed to get the correct size of the svg
    // when adding charts in the WP editor
    setTimeout(() => {
      handleResize()
    }, 0)
    // Remove event listener on cleanup
    return () => {
      window.removeEventListener('load', handleResize)
      window.removeEventListener('resize', handleResize)
      window.removeEventListener('tabsReady', handleResize)
    }
  }, [className, svgRef])
  return size
}

export { useSize }
