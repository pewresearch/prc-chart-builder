const abbreviateNumber = (num: number, fixed?: number): string => {
  if (num === null) {
    return ''
  } // terminate early
  if (num === 0) {
    return '0'
  } // terminate early
  // terminate if not a number
  if (isNaN(num)) {
    return num.toString()
  }
  num = Number(num)
  fixed = !fixed || fixed < 0 ? 0 : fixed // number of decimal places to show
  var b = num.toPrecision(2).split('e'), // get power
    k =
      b.length === 1
        ? 0
        : Math.floor(Math.min(parseInt(b[1].slice(1)), 14) / 3), // floor at decimals, ceiling at trillions
    c =
      k < 1
        ? num.toFixed(0 + fixed)
        : (num / Math.pow(10, k * 3)).toFixed(1 + fixed), // divide by power
    d = Number(c) < 0 ? c : Math.abs(Number(c)), // enforce -0 is 0
    e = d + ['', 'K', 'M', 'B', 'T'][k] // append power
  return e
}

const hexToRgb = (hex: string) => {
  const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i
  hex = hex.toString().replace(shorthandRegex, function (m, r, g, b) {
    return r + r + g + g + b + b
  })

  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
  if (!result) {
    return 'black'
  }

  const rgb: number[] = [
    parseInt(result[1], 16),
    parseInt(result[2], 16),
    parseInt(result[3], 16),
  ]
  return rgb
}

function luminance(r: number, g: number, b: number) {
  var a = [r, g, b].map(function (v) {
    v /= 255
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)
  })
  return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722
}

function checkContrast(hex1: string, hex2: string) {
  const rgb1 = hexToRgb(hex1) as number[]
  const rgb2 = hexToRgb(hex2) as number[]
  var lum1 = luminance(rgb1[0], rgb1[1], rgb1[2])
  var lum2 = luminance(rgb2[0], rgb2[1], rgb2[2])
  var brightest = Math.max(lum1, lum2)
  var darkest = Math.min(lum1, lum2)
  return (brightest + 0.05) / (darkest + 0.05)
}

function labelFill(hex = '#000000'): string {
  const rgb = hexToRgb(hex) as number[]
  // set determine color contrast per W3 guidelines: https://www.w3.org/TR/AERT/#color-contrast
  // Color brightness = ((Red value X 299) + (Green value X 587) + (Blue value X 114)) / 1000
  // The range for color brightness difference is 125.
  const brightness = Math.round(
    (rgb[0] * 299 + rgb[1] * 587 + rgb[2] * 114) / 1000,
  )
  const fill = brightness > 125 ? 'black' : 'white'
  return fill
}

const newDateByFormat = (date: string, format: string | null | undefined) => {
  if (!format) {
    return new Date(date)
  }
  if (format === 'YYYY-MM-DD') {
    const dateArray = date.split('-')
    return new Date(
      parseInt(dateArray[0]),
      parseInt(dateArray[1]) - 1,
      parseInt(dateArray[2]),
    )
  }
  if (format === 'YYYY-MM') {
    const dateArray = date.split('-')
    return new Date(parseInt(dateArray[0]), parseInt(dateArray[1]) - 1, 1)
  }
  if (format === 'MM-DD-YYYY') {
    const dateArray = date.split('-')
    return new Date(
      parseInt(dateArray[2]),
      parseInt(dateArray[0]) - 1,
      parseInt(dateArray[1]),
    )
  }
  if (format === 'DD-MM-YYYY') {
    const dateArray = date.split('-')
    return new Date(
      parseInt(dateArray[2]),
      parseInt(dateArray[1]) - 1,
      parseInt(dateArray[0]),
    )
  }
  if (format === 'MM-YYYY') {
    const dateArray = date.split('-')
    return new Date(parseInt(dateArray[1]), parseInt(dateArray[0]) - 1, 1)
  }
  if (format === 'YYYY') {
    return new Date(parseInt(date), 0, 1)
  }
  if (format === 'MM/DD/YYYY') {
    const dateArray = date.split('/')
    return new Date(
      parseInt(dateArray[2]),
      parseInt(dateArray[0]) - 1,
      parseInt(dateArray[1]),
    )
  }
  if (format === 'MM/YYYY') {
    const dateArray = date.split('/')
    return new Date(parseInt(dateArray[1]), parseInt(dateArray[0]) - 1, 1)
  }
  if (format === 'DD/MM/YYYY') {
    const dateArray = date.split('/')
    return new Date(
      parseInt(dateArray[2]),
      parseInt(dateArray[1]) - 1,
      parseInt(dateArray[0]),
    )
  }
  if (format === 'MM/DD') {
    const dateArray = date.split('/')
    return new Date(
      new Date().getFullYear(),
      parseInt(dateArray[0]) - 1,
      parseInt(dateArray[1]),
    )
  }
  if (format === 'DD/MM') {
    const dateArray = date.split('/')
    return new Date(
      new Date().getFullYear(),
      parseInt(dateArray[1]) - 1,
      parseInt(dateArray[0]),
    )
  }
  if (format === 'MM') {
    return new Date(new Date().getFullYear(), parseInt(date) - 1, 1)
  }
  return new Date(date)
}

const scaleAxisNumTicks = (
  numTicks: number,
  chartWidth: number,
  layoutWidth: number,
) => {
  // if there are 3 or less ticks, don't scale.
  // this should typically fit on the chart
  if (numTicks <= 3) {
    return numTicks
  }
  const chartToLayoutRatio = chartWidth / layoutWidth
  if (chartToLayoutRatio > 1) {
    return numTicks
  }
  const scaledNumTicks = Math.floor(numTicks * chartToLayoutRatio)
  return scaledNumTicks
}

export {
  abbreviateNumber,
  labelFill,
  newDateByFormat,
  checkContrast,
  scaleAxisNumTicks,
}
