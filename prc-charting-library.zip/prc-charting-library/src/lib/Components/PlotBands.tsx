import { PlotBands as PlotBandsType } from '../ts/types/configTypes'

type PlotBandsProps = {
  plotBands: PlotBandsType
  independentScale: any
  innerHeight: number
}

export const PlotBands = ({
  plotBands,
  independentScale,
  innerHeight,
}: PlotBandsProps) => {
  return (
    <>
      {plotBands.bands.map((band, i: number) => {
        const { x, y, style, label } = band
        const { band: bandStyle, label: labelStyle } = style
        return (
          <g>
            <rect
              fill={bandStyle.fill}
              fillOpacity={bandStyle.fillOpacity}
              key={`plot-band-${i}`}
              x={independentScale(new Date(x[0]))}
              width={
                independentScale(new Date(x[1])) -
                independentScale(new Date(x[0]))
              }
              height={innerHeight}
            />
            <text
              x={independentScale(new Date(x[0])) + labelStyle.dx}
              y={
                'top' === labelStyle.align
                  ? labelStyle.dy
                  : innerHeight - labelStyle.dy
              }
              fill={labelStyle.fill}
              fontSize={labelStyle.fontSize}
              // rotate text 90 degrees but keep it centered
              transform={
                labelStyle.orientation === 'vertical'
                  ? `rotate(90, ${independentScale(new Date(x[0]))}, 30)`
                  : ''
              }
            >
              {label}
            </text>
          </g>
        )
      })}
    </>
  )
}
