// TODO: should we abstract this out from specific chart types? It's hard to abstract the scales, but we might be able to
const Zoom = () => <span>Zoom component tk</span>

export default Zoom
