import { useContext, useMemo, useRef } from 'react'

import { DataContext } from '../Utilities/DataContext'
import { useSize, labelFill } from '../Utilities'
import {
  getLabelFormat,
  positionBarLabel,
  getChartDimensions,
  getTooltipFormat,
  getTooltipHeaderFormat,
  getSharedProps,
} from './shared'
import { StyledTooltip, StyledLegend } from './index'
import type { FlatData } from '../ts/types/flatData'
import type { Size } from '../ts/types/windowSize'
import type { BaseConfig } from '../ts/types/configTypes'
import type { TableData } from '../ts/types/tableData'

import { BarGroup, Bar } from '@visx/shape'
import { Group } from '@visx/group'
import { GridRows, GridColumns } from '@visx/grid'
import { AxisBottom, AxisLeft } from '@visx/axis'
import { scaleLinear, scaleBand, scaleOrdinal } from '@visx/scale'
import { useTooltip } from '@visx/tooltip'
import { localPoint } from '@visx/event'
import { ascending, descending } from 'd3-array'
import { LegendOrdinal } from '@visx/legend'

const BarVertical = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }
  const {
    dependentAxis,
    independentAxis,
    layout,
    colors,
    dataRender,
    tooltip,
    labels,
    legend,
    bar,
  } = config

  // SIZE AND LAYOUT
  const { height, parentClass, padding, theme } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)

  const { chartWidth, innerWidth, innerHeight } = getChartDimensions(
    size,
    layout,
  )

  // DATA PROCESSING
  const flattenedData = data.reduce((acc: string | any[], curr: any) => {
    return acc.concat(curr)
  }, [])
  // this feels counterintuitive, but we need to sort the data backwards so that it renders in the correct order
  flattenedData.sort((a: FlatData, b: FlatData) => {
    if (dataRender.sortOrder === 'ascending') {
      return descending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    if (dataRender.sortOrder === 'descending') {
      return ascending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    return 0
  })

  // DATA ACCESSORS
  const getIndependentValue = (d: FlatData) => d[dataRender.x].toString()
  // SCALES, VORONOI, INTERPOLATION
  const independentValues = flattenedData.map(getIndependentValue)
  const independentScale = useMemo(
    () =>
      scaleBand<string>({
        domain: independentValues,
        padding: bar.barGroupPadding,
      }),
    [independentValues, bar.barGroupPadding],
  )
  const keyScale = useMemo(
    () =>
      scaleBand<string>({
        domain: dataRender.categories,
        padding: bar.barPadding,
      }),
    [dataRender.categories, bar.barPadding],
  )
  const dependentScale = useMemo(
    () =>
      scaleLinear({
        domain: dependentAxis.domain,
        range: [innerHeight, 0],
        nice: true,
      }),
    [innerHeight, dependentAxis.domain],
  )
  const colorScale = useMemo(
    () =>
      scaleOrdinal<string, string>({
        domain: dataRender.categories,
        range: colors,
      }),
    [dataRender.categories, colors],
  )
  dependentScale.rangeRound([innerHeight, 0])
  independentScale.rangeRound([0, innerWidth])
  keyScale.rangeRound([0, independentScale.bandwidth()])

  // GET SHARED LAYOUT PROPS
  const {
    dependentAxisProps,
    independentAxisProps,
    dependentGridProps,
    independentGridProps,
    ariaProps,
    legendProps,
    tooltipVisible,
    labelProps,
  } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A column chart',
        config,
        data: flattenedData,
        size,
        tableData,
        dependentScale,
        independentScale,
      }),
    [config, flattenedData, size, tableData, dependentScale, independentScale],
  )

  // TOOLTIP AND HANDLERS
  const {
    tooltipData,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip<FlatData>()

  let tooltipTimeout: number

  return (
    <div style={{ position: 'relative' }}>
      <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
        <Group top={padding.top} left={padding.left} role='presentation'>
          <GridRows {...dependentGridProps} />
          <GridColumns {...independentGridProps} />
          <BarGroup
            data={flattenedData}
            keys={dataRender.categories}
            height={innerHeight}
            width={innerWidth}
            x0={getIndependentValue}
            x0Scale={independentScale}
            x1Scale={keyScale}
            yScale={dependentScale}
            color={colorScale}
          >
            {barGroups => {
              return barGroups.map((barGroup, i) => {
                const independentValue = independentValues[i]
                return (
                  <Group
                    key={`bar-group-horizontal-${barGroup.index}-${barGroup.x0}`}
                    left={barGroup.x0}
                  >
                    {barGroup.bars.map(bar => {
                      // check if there are custom labels or tooltips in the data model
                      const customLabel = flattenedData[i]['__labels']?.[
                        bar.key
                      ]
                        ? flattenedData[i]['__labels'][bar.key]
                        : ''
                      const customTooltip = flattenedData[i]['__tooltips']?.[
                        bar.key
                      ]
                        ? flattenedData[i]['__tooltips'][bar.key]
                        : ''
                      const isHighlighted =
                        flattenedData[i]['__isHighlighted']?.[bar.key]
                      return (
                        <g key={`${barGroup.index}-${bar.index}-${bar.key}`}>
                          <Bar
                            x={bar.x}
                            y={bar.y}
                            tabIndex={0}
                            width={Math.abs(bar.width)}
                            height={bar.height}
                            fill={
                              isHighlighted
                                ? dataRender.isHighlightedColor
                                : bar.color
                            }
                            fillOpacity={
                              tooltipData &&
                              tooltipVisible &&
                              tooltip.deemphasizeSiblings &&
                              (tooltipData?.x !== independentValue ||
                                tooltipData?.y !== bar.value ||
                                tooltipData?.key !== bar.key)
                                ? tooltip.deemphasizeOpacity
                                : 1
                            }
                            onMouseLeave={() => {
                              tooltipTimeout = window.setTimeout(() => {
                                hideTooltip()
                              }, 300)
                            }}
                            onMouseMove={(event: any) => {
                              if (tooltipTimeout) clearTimeout(tooltipTimeout)
                              const eventSvgCoords = localPoint(event) || {
                                x: 0,
                                y: 0,
                              }
                              showTooltip({
                                tooltipData: {
                                  x: independentValue,
                                  y: bar.value,
                                  key: bar.key,
                                  customTooltip,
                                },
                                tooltipTop: eventSvgCoords.y,
                                tooltipLeft: eventSvgCoords.x,
                              })
                            }}
                            onBlur={() => {
                              tooltipTimeout = window.setTimeout(() => {
                                hideTooltip()
                              }, 300)
                            }}
                            onFocus={() => {
                              if (tooltipTimeout) clearTimeout(tooltipTimeout)
                              showTooltip({
                                tooltipLeft: bar.x,
                                tooltipTop: bar.y,
                                tooltipData: {
                                  x: independentValue,
                                  y: bar.value,
                                  key: bar.key,
                                  customTooltip,
                                  fill: bar.color,
                                },
                              })
                            }}
                          />
                          {bar.value && labels.active && (
                            <text
                              key={`bar-group-horizontal-${barGroup.index}-${barGroup.x0}-label`}
                              {...positionBarLabel(
                                bar,
                                labels,
                                labels.labelCutoff,
                                'vertical',
                                'single',
                              )}
                              {...labelProps}
                              fill={
                                labels.labelPositionBar === 'outside' ||
                                bar.value <= labels.labelCutoff
                                  ? theme === 'light'
                                    ? 'black'
                                    : 'white'
                                  : labelFill(
                                      isHighlighted
                                        ? dataRender.isHighlightedColor
                                        : bar.color,
                                    )
                              }
                              fillOpacity={
                                tooltipData &&
                                tooltipVisible &&
                                tooltip.deemphasizeSiblings &&
                                (tooltipData?.x !== independentValue ||
                                  tooltipData?.y !== bar.value ||
                                  tooltipData?.key !== bar.key)
                                  ? tooltip.deemphasizeOpacity
                                  : 1
                              }
                            >
                              {`${
                                customLabel
                                  ? customLabel
                                  : getLabelFormat(
                                      bar.value,
                                      bar.key,
                                      labels,
                                      null,
                                    )
                              }`}
                            </text>
                          )}
                        </g>
                      )
                    })}
                  </Group>
                )
              })
            }}
          </BarGroup>
          {independentAxis.active && (
            <AxisBottom
              {...independentAxisProps}
              tickValues={independentValues}
              scale={independentScale}
              top={innerHeight}
              numTicks={flattenedData.length}
            />
          )}
          {dependentAxis.active && (
            <AxisLeft
              {...dependentAxisProps}
              scale={dependentScale}
              numTicks={undefined}
            />
          )}
        </Group>
      </svg>
      {legend.active && (
        <StyledLegend legend={legend} theme={theme}>
          <LegendOrdinal
            {...legendProps}
            scale={colorScale}
            domain={
              legend.categories.length > 0
                ? legend.categories
                : colorScale.domain()
            }
          />
        </StyledLegend>
      )}
      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: tooltipData.x,
                      category: tooltipData.key,
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData.customTooltip
                ? tooltipData.customTooltip
                : getTooltipFormat(
                    {
                      x: tooltipData.x,
                      y: tooltipData.y,
                      category: tooltipData.key,
                      color: colorScale(tooltipData.key),
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default BarVertical
