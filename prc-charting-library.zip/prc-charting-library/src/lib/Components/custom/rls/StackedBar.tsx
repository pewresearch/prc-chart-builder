import { useCallback, useContext, useMemo, useRef } from 'react'

import { DataContext } from '../../../Utilities/DataContext'
import { useSize, labelFill } from '../../../Utilities'
import { StyledTooltip } from '../../index'
import {
  getChartDimensions,
  getLabelFormat,
  getTooltipFormat,
  getTooltipHeaderFormat,
  positionBarLabel,
  getSharedProps,
  getDataWithGroupBreaks,
} from '../../shared'
import type { FlatData } from '../../../ts/types/flatData'
import type { Size } from '../../../ts/types/windowSize'
import type { BaseConfig } from '../../../ts/types/configTypes'
import type { TableData } from '../../../ts/types/tableData'

import { Bar, BarStackHorizontal, Line } from '@visx/shape'
import { Group } from '@visx/group'
import { AxisLeft } from '@visx/axis'
import { scaleLinear, scaleBand, scaleOrdinal } from '@visx/scale'
import { useTooltip } from '@visx/tooltip'
import { localPoint } from '@visx/event'
import { LegendOrdinal } from '@visx/legend'
import { PatternLines } from '@visx/pattern'
import { Text } from '@visx/text'
import { ascending, descending } from 'd3-array'

const RLSStackedBar = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }
  const {
    dependentAxis,
    independentAxis,
    layout,
    colors,
    dataRender,
    tooltip,
    labels,
    legend,
    bar: barConfig,
    diffColumn,
    custom,
  } = config
  const trendable = custom.attributes?.trendable || ''
  const isCompareChart = custom.attributes?.isCompareChart || false
  const { height, width, parentClass, padding, theme } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)
  const { chartWidth, innerWidth, innerHeight } = getChartDimensions(
    size,
    layout,
    diffColumn,
  )
  let labelCutoff =
    size.width && size.width >= width
      ? labels.labelCutoff
      : labels.labelCutoffMobile

  // DATA PROCESSING
  let flattenedData = data
    .reduce((acc: string | any[], curr: any) => {
      return acc.concat(curr)
    }, [])
    .map((row: any) => {
      return Object.keys(row).reduce((acc, key) => {
        const value = isNaN(row[key]) ? row[key] : parseFloat(row[key])
        return {
          ...acc,
          [key]: value,
        }
      }, {})
    })
  // this feels counterintuitive, but we need to sort the data backwards so that it renders in the correct order
  flattenedData.sort((a: FlatData, b: FlatData) => {
    if (dataRender.sortOrder === 'ascending') {
      return ascending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    if (dataRender.sortOrder === 'descending') {
      return descending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    return 0
  })

  // check custom attributes to see if custom.attribtues.trendable === 'caution'.
  // if so, we have a break between the first and second group
  if (trendable === 'caution') {
    barConfig.groupBreaksActive = true
    barConfig.groupBreaks.values = [2024]
    flattenedData = getDataWithGroupBreaks(flattenedData, barConfig)
  }

  if (isCompareChart) {
    barConfig.groupBreaksActive = true
    barConfig.groupBreaks.values = ['U.S. population']
    flattenedData = getDataWithGroupBreaks(flattenedData, barConfig)
    flattenedData.reverse()
  }

  // DATA ACCESSORS
  const getIndependentValue = useCallback(
    (d: FlatData) => {
      const independentValue = d[dataRender.x]
      // lol this is so bad
      if (
        independentValue === 2024 &&
        (trendable === 'caution' || trendable === 'untrendable')
      ) {
        return '2023-24*'
      }
      if (independentValue === 2024 && trendable !== 'caution') {
        return '2023-24'
      }
      if (trendable === 'untrendable') {
        return independentValue + '*'
      }
      if (d['__axisLabel']) {
        return d['__axisLabel']
      }
      // add a space after any forward slashes in the independent value
      return independentValue as string
    },
    [dataRender.x],
  )
  const getDependentValue = (d: FlatData) => d[dataRender.y]

  // SCALES, VORONOI, INTERPOLATION

  const independentScale = useMemo(
    () =>
      scaleBand<string>({
        domain: flattenedData.map(getIndependentValue),
        padding: barConfig.barPadding,
      }),
    [flattenedData, getIndependentValue, barConfig.barPadding],
  )
  const dependentScale = useMemo(
    () =>
      scaleLinear({
        domain: dependentAxis.domain,
        range: [0, innerWidth],
        nice: true,
      }),
    [innerWidth, dependentAxis.domain],
  )
  const colorScale = useMemo(
    () =>
      scaleOrdinal<string, string>({
        domain: dataRender.categories,
        range: colors,
      }),
    [dataRender.categories, colors],
  )
  dependentScale.rangeRound([0, innerWidth])
  independentScale.rangeRound([innerHeight, 0])
  // TODO: temporary fix to check if 2024 data exists on caution trendable data. Final dataset should have this resolved.
  const has2024Data = flattenedData.some(
    (d: FlatData) => d[dataRender.x] === 2024,
  )
  // GET SHARED LAYOUT PROPS
  const {
    independentAxisProps,
    ariaProps,
    legendProps,
    tooltipVisible,
    labelProps,
  } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A stacked horizontal bar chart',
        config,
        data: flattenedData,
        size,
        tableData,
        dependentScale,
        independentScale,
      }),
    [config, flattenedData, size, tableData, dependentScale, independentScale],
  )

  // TOOLTIP AND HANDLERS
  const {
    tooltipData,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip<FlatData>()
  let tooltipTimeout: number

  return (
    <div
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {legend.active && (
        <div
          className='cb__legend__inner'
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            backgroundColor: theme === 'light' ? legend.fill : '#1e1e1e',
            border: legend.borderStroke
              ? `1px solid ${theme === 'light' ? legend.borderStroke : '#fff'}`
              : 'none',
            fontSize: '12px',
          }}
        >
          <LegendOrdinal
            {...legendProps}
            scale={colorScale}
            domain={
              legend.categories.length > 0
                ? legend.categories
                : colorScale.domain()
            }
          />
        </div>
      )}
      <div style={{ position: 'relative' }}>
        <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
          <Group top={padding.top} left={padding.left} role='presentation'>
            {trendable === 'caution' && has2024Data && (
              <>
                <PatternLines
                  id={layout.name}
                  height={4}
                  width={4}
                  stroke={'#eee'}
                  strokeWidth={1}
                  orientation={['diagonal']}
                />
                <Bar
                  fill={`url('#${layout.name}')`}
                  opacity={1}
                  x={-70}
                  y={60}
                  width={600}
                  height={180}
                  rx={0}
                />
              </>
            )}
            <BarStackHorizontal
              data={flattenedData}
              keys={dataRender.categories}
              height={innerHeight}
              y={getIndependentValue}
              xScale={dependentScale}
              yScale={independentScale}
              color={colorScale}
            >
              {barStacks => {
                return barStacks.map(barStack => {
                  return barStack.bars.map((bar, i) => {
                    const category: string = bar.key
                    const barData: FlatData = bar.bar['data']
                    const barValue: number =
                      barData[category as keyof typeof barData]
                    const customLabel: string = barData['__labels']?.[category]
                      ? barData['__labels']?.[category]
                      : ''
                    const customTooltip: string = barData['__tooltips']?.[
                      category
                    ]
                      ? barData['__tooltips']?.[category]
                      : ''
                    if (barData.groupBreak && !isCompareChart) {
                      return (
                        <Text
                          x={innerWidth / 2 - 10}
                          y={bar.y + bar.height / 2 + 5}
                          fill={'#000'}
                          stroke='#fff'
                          fontWeight={700}
                          fontSize={13}
                          textAnchor='middle'
                          paintOrder={'stroke'}
                          width={innerWidth}
                          verticalAnchor='middle'
                        >
                          Trend for comparison, with caution; read note
                        </Text>
                      )
                    } else if (barData.groupBreak && isCompareChart) {
                      return (
                        <Line
                          from={{ x: -80, y: bar.y + bar.height / 2 }}
                          to={{ x: innerWidth, y: bar.y + bar.height / 2 }}
                          stroke={'#6D6F71'}
                          strokeWidth={1}
                          strokeDasharray={'3 2'}
                        />
                        // <Text
                        //   x={innerWidth / 2 - 10}
                        //   y={bar.y + bar.height / 2 + 5}
                        //   fill={'#000'}
                        //   stroke='#fff'
                        //   fontWeight={700}
                        //   fontSize={13}
                        //   textAnchor='middle'
                        //   paintOrder={'stroke'}
                        //   width={innerWidth}
                        //   verticalAnchor='middle'
                        // >
                        //   U.S. population
                        // </Text>
                      )
                    } else {
                      return (
                        <g
                          key={`barstack-horizontal-${barStack.index}-${bar.index}`}
                        >
                          <rect
                            x={bar.x}
                            y={bar.y}
                            width={barValue ? Math.abs(bar.width) : 0}
                            height={bar.height}
                            fill={bar.color}
                            tabIndex={0}
                            stroke={
                              barConfig.hasRectStroke
                                ? barConfig.rectStrokeColor
                                : 'none'
                            }
                            strokeWidth={
                              barConfig.hasRectStroke
                                ? barConfig.rectStrokeWidth
                                : '0'
                            }
                            fillOpacity={1}
                            onBlur={() => {
                              tooltipTimeout = window.setTimeout(() => {
                                hideTooltip()
                              }, 300)
                            }}
                            onFocus={() => {
                              if (tooltipTimeout) clearTimeout(tooltipTimeout)
                              showTooltip({
                                tooltipData: {
                                  x: barData.x,
                                  y: barValue,
                                  category,
                                  tooltip: customTooltip,
                                },
                                tooltipTop: bar.y,
                                tooltipLeft: bar.x,
                              })
                            }}
                            onMouseLeave={() => {
                              tooltipTimeout = window.setTimeout(() => {
                                hideTooltip()
                              }, 300)
                            }}
                            onMouseMove={event => {
                              if (tooltipTimeout) clearTimeout(tooltipTimeout)
                              const eventSvgCoords = localPoint(event) || {
                                x: 0,
                                y: 0,
                              }
                              showTooltip({
                                tooltipData: {
                                  x: barData.x,
                                  y: barValue,
                                  category,
                                  tooltip: customTooltip,
                                },
                                tooltipTop: eventSvgCoords.y,
                                tooltipLeft: eventSvgCoords.x,
                              })
                            }}
                          />
                          {barValue &&
                            labels.active &&
                            labelCutoff < barValue && (
                              <text
                                key={`barstack-horizontal-label-${barStack.index}-${bar.index}`}
                                {...positionBarLabel(
                                  {
                                    x: bar.x,
                                    y: bar.y,
                                    width: bar.width,
                                    height: bar.height,
                                    value: barValue,
                                  },
                                  labels,
                                  labelCutoff,
                                  'horizontal',
                                  'stacked',
                                )}
                                {...labelProps}
                                stroke={
                                  labelFill(bar.color) === 'white'
                                    ? '#000'
                                    : '#fff'
                                }
                                paintOrder={'stroke'}
                                fill={labelFill(bar.color)}
                                fillOpacity={
                                  tooltipData &&
                                  tooltipVisible &&
                                  tooltip.deemphasizeSiblings &&
                                  (tooltipData?.x !== barData.x ||
                                    tooltipData?.y !== barValue ||
                                    tooltipData?.category !== category)
                                    ? tooltip.deemphasizeOpacity
                                    : 1
                                }
                              >
                                {i !== barStack.bars.length - 1
                                  ? customLabel.replace('%', '')
                                  : customLabel}
                              </text>
                            )}
                        </g>
                      )
                    }
                  })
                })
              }}
            </BarStackHorizontal>
            {independentAxis.active && (
              <AxisLeft
                {...independentAxisProps}
                tickValues={independentScale.domain()}
                scale={independentScale}
                numTicks={flattenedData.length}
                stroke='transparent'
                tickStroke='transparent'
                tickFormat={(t: any) => {
                  // add a space after any forward slashes in the independent value
                  // to force a word break
                  return t.toString().replace(/\//g, '/ ')
                }}
              />
            )}
          </Group>
        </svg>
        {tooltipOpen && tooltipData && tooltipVisible && (
          <StyledTooltip
            top={tooltipTop}
            left={tooltipLeft}
            tooltip={tooltip}
            theme={theme}
          >
            <>
              {tooltip.headerActive && (
                <div
                  style={{
                    marginBottom: '10px',
                  }}
                >
                  <strong>
                    {getTooltipHeaderFormat(
                      {
                        x: getIndependentValue(tooltipData),
                        category: tooltipData.category,
                      },
                      tooltip,
                    )}
                  </strong>
                </div>
              )}
            </>
            <div
              dangerouslySetInnerHTML={{
                __html: tooltipData.tooltip
                  ? tooltipData.tooltip
                  : getTooltipFormat(
                      {
                        x: getIndependentValue(tooltipData),
                        y: getDependentValue(tooltipData),
                        category: tooltipData.category,
                        color: colorScale(tooltipData.category || ''),
                      },
                      tooltip,
                      dataRender,
                    ),
              }}
            />
          </StyledTooltip>
        )}
      </div>
    </div>
  )
}

export default RLSStackedBar
