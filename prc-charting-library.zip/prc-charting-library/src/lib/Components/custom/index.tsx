import RLSStackedBar from './rls/StackedBar'
import { Custom } from '../../ts/types/custom'

const CustomChartRenderer = ({ attributes }: Custom): JSX.Element => {
  const { chartType } = attributes
  switch (chartType) {
    case 'rls-stacked-bar':
      return <RLSStackedBar />
    default:
      return <></>
  }
}

export default CustomChartRenderer
