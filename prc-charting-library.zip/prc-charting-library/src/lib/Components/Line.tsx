import { CSSProperties, useCallback, useContext, useMemo, useRef } from 'react'

import { DataContext } from '../Utilities/DataContext'
import { useSize, scaleAxisNumTicks } from '../Utilities'
import {
  getChartDimensions,
  getLabelFormat,
  getTooltipFormat,
  getTooltipHeaderFormat,
  getSharedProps,
} from './shared'
import { newDateByFormat } from '../Utilities'
import { StyledTooltip, StyledLegend, PlotBands } from './index'
import type { FlatData } from '../ts/types/flatData'
import type { Size } from '../ts/types/windowSize'
import type { BaseConfig } from '../ts/types/configTypes'

import {
  AreaClosed,
  LinePath,
  // Line as VerticalLine,
  Circle,
} from '@visx/shape'
import * as Curve from '@visx/curve'
import { Group } from '@visx/group'
import { GridRows, GridColumns } from '@visx/grid'
import { AxisBottom, AxisLeft } from '@visx/axis'
import { scaleTime, scaleLinear, scaleOrdinal } from '@visx/scale'
import { useTooltip } from '@visx/tooltip'
import { localPoint } from '@visx/event'
import { voronoi, VoronoiPolygon } from '@visx/voronoi'
import { max, extent, ascending, descending } from 'd3-array'
import { LegendOrdinal } from '@visx/legend'

import styled from '@emotion/styled'

type CurveType = typeof Curve

const StyledCircle = styled(Circle)`
  &:focus {
    outline: none;
  }
`

const Line = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: any
  }
  const {
    dependentAxis,
    independentAxis,
    line,
    layout,
    colors,
    nodes,
    dataRender,
    tooltip,
    labels,
    legend,
    plotBands,
    voronoi: voronoiConfig,
    events,
  } = config

  // SIZE AND LAYOUT
  const { width, height, parentClass, padding } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)

  const { chartWidth, innerWidth, innerHeight, overflow } = getChartDimensions(
    size,
    layout,
  )

  let scaledNumTicks = useMemo(
    () => scaleAxisNumTicks(independentAxis.tickCount || 5, chartWidth, width),
    [independentAxis.tickCount, chartWidth, width],
  )

  // DATA PROCESSING
  const flattenedData = useMemo(
    () =>
      data.reduce((acc: string | any[], curr: any) => {
        return acc.concat(curr)
      }, []),
    [data],
  )
  flattenedData.sort((a: FlatData, b: FlatData) => {
    if (dataRender.sortOrder === 'ascending') {
      if (independentAxis.scale === 'time') {
        return ascending(
          newDateByFormat(a[dataRender.x], dataRender.xFormat) as Date,
          newDateByFormat(b[dataRender.x], dataRender.xFormat) as Date,
        )
      }
      return ascending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    if (dataRender.sortOrder === 'descending') {
      return descending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    return 0
  })

  // to render the voronoi, we need to flatten the data further,
  // assigning each point its own polygon

  const voronoiData = useMemo(
    () =>
      flattenedData
        .map((d: FlatData) =>
          // eslint-disable-next-line array-callback-return
          dataRender.categories.map((c: string, i: number) => {
            if (d[c])
              return {
                x: d.x,
                y: d[c],
                category: c,
                label: d['__labels']?.[c] ? d['__labels'][c] : '',
                tooltip: d['__tooltips']?.[c] ? d['__tooltips'][c] : '',
                color: colors[i],
              }
          }),
        )
        .flat()
        .filter(Boolean),
    [dataRender, flattenedData],
  )

  // DATA ACCESSORS

  const getIndependentValue = useCallback(
    (d: FlatData) => {
      if (independentAxis.scale === 'time') {
        return newDateByFormat(d[dataRender.x], dataRender.xFormat) as Date
      } else {
        return d[dataRender.x] as number
      }
    },
    [dataRender, independentAxis],
  )

  const getDependentValue = useCallback(
    (d: FlatData) => d[dataRender.y] as number,
    [dataRender],
  )

  // SCALES, VORONOI, INTERPOLATION
  const timeScale = useMemo(
    () =>
      scaleTime({
        domain: extent(flattenedData, getIndependentValue) as [Date, Date],
        range: [0, innerWidth],
      }),
    [innerWidth, flattenedData, getIndependentValue],
  )
  const linearScale = useMemo(
    () =>
      scaleLinear({
        domain: independentAxis.domain
          ? independentAxis.domain
          : [0, max(flattenedData, getIndependentValue) || 0],
        range: [0, innerWidth],
      }),
    [innerWidth, independentAxis, flattenedData, getIndependentValue],
  )
  const independentScale =
    independentAxis.scale === 'time' ? timeScale : linearScale
  const dependentScale = useMemo(
    () =>
      scaleLinear({
        domain: dependentAxis.domain
          ? dependentAxis.domain
          : [0, max(flattenedData, getDependentValue) || 0],
        range: [innerHeight, 0],
        nice: true,
      }),
    [innerHeight, flattenedData, dependentAxis, getDependentValue],
  )
  const colorScale = useMemo(
    () =>
      scaleOrdinal<string, string>({
        domain: dataRender.categories,
        range: colors,
      }),
    [dataRender.categories, colors],
  )
  const voronoiLayout = useMemo(
    () =>
      voronoi<FlatData>({
        x: d => independentScale(getIndependentValue(d)),
        y: d => dependentScale(getDependentValue(d)),
        width: innerWidth,
        height: innerHeight,
      })(voronoiData),
    [
      innerWidth,
      innerHeight,
      independentScale,
      dependentScale,
      voronoiData,
      getIndependentValue,
      getDependentValue,
    ],
  )
  const interpolation: keyof CurveType = line.interpolation

  // GET SHARED LAYOUT PROPS
  const {
    dependentAxisProps,
    independentAxisProps,
    dependentGridProps,
    independentGridProps,
    voronoiProps,
    ariaProps,
    legendProps,
    tooltipVisible,
    labelProps,
  } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A line chart',
        config,
        data: flattenedData,
        size,
        tableData,
        dependentScale,
        independentScale,
      }),
    [config, flattenedData, size, tableData, dependentScale, independentScale],
  )

  // TOOLTIP AND HANDLERS
  const {
    tooltipData,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip<FlatData>()

  let tooltipTimeout: number = 0

  const handleMouseMove = useCallback(
    (event: React.MouseEvent | React.TouchEvent) => {
      if (tooltipTimeout) clearTimeout(tooltipTimeout)
      if (!svgRef.current) return

      // find the nearest polygon to the current mouse position
      const point = localPoint(svgRef.current, event)
      if (!point) return
      const closest = voronoiLayout.find(
        point.x - padding.left,
        point.y - padding.top,
      )
      if (closest) {
        showTooltip({
          tooltipLeft: independentScale(getIndependentValue(closest.data)),
          tooltipTop: dependentScale(getDependentValue(closest.data)),
          tooltipData: closest.data,
        })
      }
    },
    [
      independentScale,
      dependentScale,
      showTooltip,
      voronoiLayout,
      getDependentValue,
      getIndependentValue,
      layout,
      tooltipTimeout,
    ],
  )
  const handleOnClick = useCallback(
    (event: React.MouseEvent | React.TouchEvent) => {
      if (events.click) {
        if (!svgRef.current) return

        // find the nearest polygon to the current mouse position
        const point = localPoint(svgRef.current, event)
        if (!point) return
        const closest = voronoiLayout.find(
          point.x - padding.left,
          point.y - padding.top,
        )
        if (closest) {
          events.click(closest.data, event)
        }
      }
    },
    [voronoiLayout, layout, events.click],
  )

  const handleMouseLeave = useCallback(() => {
    // eslint-disable-next-line react-hooks/exhaustive-deps
    tooltipTimeout = window.setTimeout(() => {
      hideTooltip()
    }, 300)
  }, [hideTooltip])

  return (
    <div
      style={{
        position: 'relative',
        overflowX: overflow as CSSProperties['overflowX'],
      }}
    >
      <svg {...ariaProps} width={chartWidth} height={height} ref={svgRef}>
        <Group
          top={padding.top}
          left={padding.left}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          onClick={handleOnClick}
          role='presentation'
        >
          {plotBands.active && (
            <PlotBands
              plotBands={plotBands}
              independentScale={independentScale}
              innerHeight={innerHeight}
            />
          )}
          <GridRows {...dependentGridProps} />
          <GridColumns {...independentGridProps} />
          {voronoiConfig.active &&
            voronoiLayout
              .polygons()
              .map((polygon, i) => (
                <VoronoiPolygon
                  {...voronoiProps}
                  key={`polygon-${i}`}
                  polygon={polygon}
                  fillOpacity={tooltipData === polygon.data ? 0.1 : 0}
                />
              ))}
          {dependentAxis.active && <AxisLeft {...dependentAxisProps} />}
          {independentAxis.active && (
            <AxisBottom
              {...independentAxisProps}
              top={innerHeight}
              numTicks={scaledNumTicks}
            />
          )}
          {/* iterate over each category and render a line for each */}
          {dataRender.categories.map((category: string, i: number) => {
            // it's not guaranteed that all categories have the same number of data points
            // so we need to filter out any data points that don't have a value for the current category
            const filteredData = flattenedData.filter(
              (d: FlatData) => d[category] || d[category] !== '',
            )
            return (
              <g key={`line-group-${i}`}>
                {line.showArea && (
                  <AreaClosed
                    key={`area-${i}`}
                    data={filteredData}
                    x={(d: FlatData) =>
                      independentScale(getIndependentValue(d)) ?? 0
                    }
                    y={(d: FlatData) => dependentScale(d[category]) ?? 0}
                    yScale={dependentScale}
                    strokeWidth={0}
                    fill={colors[i]}
                    fillOpacity={line.areaFillOpacity}
                    curve={Curve[interpolation]}
                  />
                )}
                <LinePath
                  key={`line-${i}`}
                  data={filteredData}
                  x={(d: FlatData) => independentScale(getIndependentValue(d))}
                  y={(d: FlatData) => dependentScale(d[category])}
                  strokeWidth={
                    tooltipData &&
                    tooltipVisible &&
                    tooltip.deemphasizeSiblings &&
                    tooltipData.category === category
                      ? line.strokeWidth + 1
                      : line.strokeWidth
                  }
                  stroke={colors[i]}
                  strokeOpacity={
                    tooltipData &&
                    tooltipVisible &&
                    tooltip.deemphasizeSiblings &&
                    tooltipData.category !== category
                      ? tooltip.deemphasizeOpacity
                      : 1
                  }
                  curve={Curve[interpolation]}
                  strokeDasharray={line.strokeDasharray}
                />
                {line.showPoints &&
                  filteredData?.map((d: FlatData, j: number) => (
                    <StyledCircle
                      key={j}
                      tabIndex={0}
                      r={nodes.pointSize}
                      cx={independentScale(getIndependentValue(d))}
                      cy={dependentScale(d[category])}
                      stroke={colors[i]}
                      strokeWidth={nodes.pointStrokeWidth}
                      fill={nodes.pointFill === 'inherit' ? colors[i] : 'white'}
                      fillOpacity={
                        tooltipData &&
                        tooltipVisible &&
                        tooltip.deemphasizeSiblings &&
                        tooltipData.category !== category
                          ? tooltip.deemphasizeOpacity
                          : 1
                      }
                      onBlur={() => {
                        tooltipTimeout = window.setTimeout(() => {
                          hideTooltip()
                        }, 300)
                      }}
                      onFocus={() => {
                        if (tooltipTimeout) clearTimeout(tooltipTimeout)
                        showTooltip({
                          tooltipLeft: independentScale(getIndependentValue(d)),
                          tooltipTop: dependentScale(d[category]),
                          tooltipData: {
                            x: d.x,
                            y: d[category],
                            category: category,
                            color: colors[i],
                          },
                        })
                      }}
                    />
                  ))}
                {labels.active &&
                  filteredData?.map((d: FlatData, j: number) => {
                    const customLabel = d['__labels']?.[category]
                      ? d['__labels'][category]
                      : ''
                    return (
                      <text
                        key={`line-group-${j}-label`}
                        {...labelProps}
                        x={independentScale(getIndependentValue(d))}
                        y={dependentScale(d[category])}
                        dy={labels.labelPositionDY}
                        dx={labels.labelPositionDX}
                        fill={
                          labels.color === 'inherit' ? colors[i] : labels.color
                        }
                      >
                        {/* if custom label is provided */}
                        {customLabel}
                        {/* if is the first or last in series */}
                        {!customLabel &&
                        labels.showFirstLastPointsOnly &&
                        (j === 0 || j === filteredData.length - 1)
                          ? `${getLabelFormat(
                              d[category],
                              category,
                              labels,
                              null,
                            )}`
                          : ''}
                        {!customLabel &&
                          !labels.showFirstLastPointsOnly &&
                          `${getLabelFormat(
                            d[category],
                            category,
                            labels,
                            null,
                          )}`}
                      </text>
                    )
                  })}
                {tooltipData && tooltipVisible && (
                  <g>
                    <Circle
                      cx={tooltipLeft}
                      cy={tooltipTop}
                      r={nodes.pointSize + 2}
                      fill={colorScale(tooltipData.category || '')}
                      fillOpacity={line.showPoints ? 0.1 : 1}
                      stroke={colorScale(tooltipData.category || '')}
                      strokeOpacity={0.1}
                      strokeWidth={2}
                      pointerEvents='none'
                    />
                    <Circle
                      cx={tooltipLeft}
                      cy={tooltipTop}
                      r={nodes.pointSize + 1}
                      fill='transparent'
                      stroke='white'
                      strokeWidth={2}
                      pointerEvents='none'
                    />
                  </g>
                )}
              </g>
            )
          })}
        </Group>
      </svg>
      {legend.active && (
        <StyledLegend
          legend={legend}
          theme={layout.theme}
          layoutWidth={width}
          chartWidth={chartWidth}
        >
          <LegendOrdinal
            {...legendProps}
            scale={scaleOrdinal<string, string>({
              domain: dataRender.categories,
              range: colors,
            })}
            domain={
              legend.categories.length > 0
                ? legend.categories
                : colorScale.domain()
            }
          />
        </StyledLegend>
      )}
      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={layout.theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: getIndependentValue(tooltipData),
                      category: tooltipData.category,
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData.tooltip
                ? tooltipData.tooltip
                : getTooltipFormat(
                    {
                      x: getIndependentValue(tooltipData),
                      y: getDependentValue(tooltipData),
                      category: tooltipData.category,
                      color: colorScale(tooltipData.category || ''),
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default Line
