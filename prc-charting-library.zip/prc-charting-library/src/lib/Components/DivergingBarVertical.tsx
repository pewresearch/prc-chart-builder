import { useCallback, useContext, useMemo, useRef } from 'react'

import { DataContext } from '../Utilities/DataContext'
import { useSize, labelFill } from '../Utilities'
import {
  getChartDimensions,
  getLabelFormat,
  getSharedProps,
  getTooltipFormat,
  getTooltipHeaderFormat,
  positionBarLabel,
} from './shared'
import { StyledTooltip, StyledLegend } from './index'
import type { FlatData } from '../ts/types/flatData'
import type { Size } from '../ts/types/windowSize'
import type { BaseConfig } from '../ts/types/configTypes'
import type { TableData } from '../ts/types/tableData'

import { BarStack, Line } from '@visx/shape'
import { Group } from '@visx/group'
import { AxisBottom, AxisLeft } from '@visx/axis'
import { scaleBand, scaleLinear, scaleOrdinal } from '@visx/scale'
import { ascending, descending } from 'd3-array'
import { useTooltip } from '@visx/tooltip'
import { LegendOrdinal } from '@visx/legend'

import { localPoint } from '@visx/event'
import { GridColumns, GridRows } from '@visx/grid'

const DivergingBarVertical = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }
  const {
    dependentAxis,
    independentAxis,
    layout,
    colors,
    dataRender,
    tooltip,
    labels,
    legend,
    divergingBar,
    bar: barConfig,
  } = config as BaseConfig

  // LAYOUT
  const { width, height, parentClass, padding, theme } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)
  const { chartWidth, innerWidth, innerHeight } = getChartDimensions(
    size,
    layout,
  )
  let labelCutoff =
    size.width && size.width >= width
      ? labels.labelCutoff
      : labels.labelCutoffMobile
  // DATA PROCESSING
  // this data is a little different than the others. Because the data stack's offset is divergent,
  // we need to convert the keys that belong to the negative categories to negative values
  const flattenedData = data
    .reduce((acc: string | any[], curr: any) => {
      return acc.concat(curr)
    }, [])
    .map((row: any) => {
      return Object.keys(row).reduce((acc, key) => {
        const value = row[key]
        const isNegative = divergingBar.negativeCategories.includes(key)
        return {
          ...acc,
          [key]: isNegative ? -value : value,
        }
      }, {})
    })

  // this feels counterintuitive, but we need to sort the data backwards so that it renders in the correct order
  flattenedData.sort((a: FlatData, b: FlatData) =>
    dataRender.sortOrder === 'ascending'
      ? descending(a[dataRender.sortKey], b[dataRender.sortKey])
      : ascending(a[dataRender.sortKey], b[dataRender.sortKey]),
  )

  // DATA ACCESSORS
  const getIndependentValue = useCallback(
    (d: FlatData) => d[dataRender.x],
    [dataRender.x],
  )

  // SCALES, VORONOI, INTERPOLATION

  const independentScale = useMemo(
    () =>
      scaleBand<string>({
        domain: flattenedData.map(getIndependentValue),
        padding: 0.2,
      }),
    [flattenedData, getIndependentValue],
  )
  const dependentScale = useMemo(
    () =>
      scaleLinear({
        domain: dependentAxis.domain,
        range: [0, innerHeight],
        nice: true,
      }),
    [innerHeight, dependentAxis.domain],
  )
  const colorScale = useMemo(
    () =>
      scaleOrdinal<string, string>({
        domain: [
          ...divergingBar.negativeCategories,
          ...divergingBar.positiveCategories,
        ],
        range: colors,
      }),
    [divergingBar, colors],
  )
  independentScale.rangeRound([0, innerWidth])
  dependentScale.range([innerHeight, 0])

  // GET SHARED LAYOUT PROPS
  const {
    dependentAxisProps,
    independentAxisProps,
    dependentGridProps,
    independentGridProps,
    ariaProps,
    legendProps,
    tooltipVisible,
    labelProps,
  } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A diverging column chart',
        config,
        data: flattenedData,
        size,
        tableData,
        dependentScale,
        independentScale,
      }),
    [config, flattenedData, size, tableData, dependentScale, independentScale],
  )

  const {
    tooltipOpen,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipData,
    hideTooltip,
    showTooltip,
  } = useTooltip<FlatData>()

  let tooltipTimeout: number

  return chartWidth && chartWidth < 10 ? null : (
    <div style={{ position: 'relative' }}>
      <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
        <Group top={padding.top} left={padding.left} role='presentation'>
          <GridRows {...independentGridProps} />
          <GridColumns {...dependentGridProps} />
          {config.dependentAxis.active && <AxisLeft {...dependentAxisProps} />}
          {config.independentAxis.active && (
            <AxisBottom {...independentAxisProps} top={innerHeight} />
          )}
          <BarStack
            data={flattenedData}
            keys={[
              ...divergingBar.negativeCategories,
              ...divergingBar.positiveCategories,
            ]}
            height={innerHeight}
            x={getIndependentValue}
            xScale={independentScale}
            yScale={dependentScale}
            color={colorScale}
            offset={'diverging'}
          >
            {barStacks =>
              barStacks.map(barStack => {
                return barStack.bars.map(bar => {
                  const category: string = bar.key
                  const barData = bar.bar['data']
                  const barValue: number =
                    barData[category as keyof typeof barData]
                  const customLabel: string = barData['__labels']?.[category]
                    ? barData['__labels']?.[category]
                    : ''
                  const customTooltip: string = barData['__tooltips']?.[
                    category
                  ]
                    ? barData['__tooltips']?.[category]
                    : ''

                  return (
                    <g
                      key={`barstack-vertical-${barStack.index}-${bar.index}-g`}
                    >
                      <rect
                        key={`barstack-vertical-${barStack.index}-${bar.index}`}
                        x={bar.x}
                        y={bar.y}
                        tabIndex={0}
                        width={bar.width}
                        height={barValue ? Math.abs(bar.height) : 0}
                        fill={bar.color}
                        fillOpacity={
                          tooltipData &&
                          tooltipVisible &&
                          tooltip.deemphasizeSiblings &&
                          (tooltipData?.x !== barData.x ||
                            tooltipData?.y !== barValue ||
                            tooltipData?.category !== category)
                            ? tooltip.deemphasizeOpacity
                            : 1
                        }
                        stroke={
                          barConfig.hasRectStroke
                            ? barConfig.rectStrokeColor
                            : 'none'
                        }
                        strokeWidth={
                          barConfig.hasRectStroke
                            ? barConfig.rectStrokeWidth
                            : '0'
                        }
                        onMouseLeave={() => {
                          tooltipTimeout = window.setTimeout(() => {
                            hideTooltip()
                          }, 300)
                        }}
                        onMouseMove={event => {
                          if (tooltipTimeout) clearTimeout(tooltipTimeout)
                          const eventSvgCoords = localPoint(event) || {
                            x: 0,
                            y: 0,
                          }
                          showTooltip({
                            tooltipData: {
                              x: barData.x,
                              y: barValue,
                              category,
                              tooltip: customTooltip,
                            },
                            tooltipTop: eventSvgCoords.y,
                            tooltipLeft: eventSvgCoords.x,
                          })
                        }}
                        onBlur={() => {
                          tooltipTimeout = window.setTimeout(() => {
                            hideTooltip()
                          }, 300)
                        }}
                        onFocus={() => {
                          if (tooltipTimeout) clearTimeout(tooltipTimeout)
                          showTooltip({
                            tooltipData: {
                              x: barData.x,
                              y: barValue,
                              category,
                              tooltip: customTooltip,
                            },
                            tooltipTop: bar.y,
                            tooltipLeft: bar.x,
                          })
                        }}
                      />
                      {barValue &&
                        labels.active &&
                        labelCutoff < Math.abs(barValue) && (
                          <text
                            key={`barstack-horizontal-label-${barStack.index}-${bar.index}`}
                            {...labelProps}
                            {...positionBarLabel(
                              {
                                x: bar.x,
                                y: bar.y,
                                width: bar.width,
                                height: bar.height,
                                value: barValue,
                              },
                              labels,
                              labelCutoff,
                              'vertical',
                              'stacked',
                            )}
                            fill={labelFill(bar.color)}
                            fillOpacity={
                              tooltipData &&
                              tooltipVisible &&
                              tooltip.deemphasizeSiblings &&
                              (tooltipData?.x !== barData.x ||
                                tooltipData?.y !== barValue ||
                                tooltipData?.category !== category)
                                ? tooltip.deemphasizeOpacity
                                : 1
                            }
                            fontSize={12}
                            style={{
                              fontSize: '12px',
                              fontFamily:
                                "'franklin-gothic-urw', Verdana, Geneva, sans-serif",
                            }}
                          >
                            {customLabel
                              ? customLabel
                              : `${getLabelFormat(
                                  barValue,
                                  bar.key,
                                  labels,
                                  null,
                                )}`}
                          </text>
                        )}
                    </g>
                  )
                })
              })
            }
          </BarStack>
          <Line
            from={{ x: 0, y: dependentScale(0) }}
            to={{ x: innerWidth + 0, y: dependentScale(0) }}
            stroke={dependentAxis.axis.stroke}
            strokeWidth={dependentAxis.axis.strokeWidth}
            pointerEvents='none'
          />
        </Group>
      </svg>
      {legend.active && (
        <StyledLegend legend={legend} theme={theme}>
          <LegendOrdinal
            {...legendProps}
            scale={colorScale}
            domain={
              legend.categories.length > 0
                ? legend.categories
                : colorScale.domain()
            }
          />
        </StyledLegend>
      )}
      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: tooltipData.x,
                      category: tooltipData.category,
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData.tooltip
                ? tooltipData.tooltip
                : getTooltipFormat(
                    {
                      x: tooltipData.x,
                      y: tooltipData.y,
                      category: tooltipData.category,
                      color: colorScale(tooltipData.category || ''),
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default DivergingBarVertical
