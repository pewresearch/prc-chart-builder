import { useCallback, useContext, useMemo, useRef } from 'react'

import { DataContext } from '../Utilities/DataContext'
import { useSize, labelFill } from '../Utilities'
import {
  getChartDimensions,
  getLabelFormat,
  getTooltipFormat,
  getTooltipHeaderFormat,
  positionBarLabel,
  getSharedProps,
} from './shared'
import { StyledTooltip, StyledLegend } from './index'

import type { FlatData } from '../ts/types/flatData'
import type { Size } from '../ts/types/windowSize'
import type { BaseConfig } from '../ts/types/configTypes'
import type { TableData } from '../ts/types/tableData'

import { BarStack } from '@visx/shape'
import { Group } from '@visx/group'
import { AxisBottom, AxisLeft } from '@visx/axis'
import { scaleBand, scaleLinear, scaleOrdinal } from '@visx/scale'
import { useTooltip } from '@visx/tooltip'
import { LegendOrdinal } from '@visx/legend'
import { localPoint } from '@visx/event'
import { GridColumns, GridRows } from '@visx/grid'

import { ascending, descending } from 'd3-array'

const StackedBarVertical = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }
  const {
    dependentAxis,
    independentAxis,
    layout,
    colors,
    dataRender,
    tooltip,
    labels,
    legend,
    bar: barConfig,
  } = config

  // SIZE AND LAYOUT
  const { height, width, parentClass, padding, theme } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)
  const { chartWidth, innerWidth, innerHeight } = getChartDimensions(
    size,
    layout,
  )
  let labelCutoff =
    size.width && size.width >= width
      ? labels.labelCutoff
      : labels.labelCutoffMobile
  // DATA PROCESSING
  const flattenedData = data.reduce((acc: string | any[], curr: any) => {
    return acc.concat(curr)
  }, [])

  flattenedData.sort((a: FlatData, b: FlatData) => {
    if (dataRender.sortOrder === 'ascending') {
      return ascending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    if (dataRender.sortOrder === 'descending') {
      return descending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    return 0
  })
  // DATA ACCESSORS
  const getIndependentValue = useCallback(
    (d: FlatData) => d[dataRender.x],
    [dataRender.x],
  )

  const getDependentValue = (d: FlatData) => d[dataRender.y]
  // SCALES, VORONOI, INTERPOLATION

  const independentScale = useMemo(
    () =>
      scaleBand<string>({
        domain: flattenedData.map(getIndependentValue),
        padding: barConfig.barPadding,
      }),
    [flattenedData, getIndependentValue, barConfig.barPadding],
  )
  const dependentScale = useMemo(
    () =>
      scaleLinear({
        domain: dependentAxis.domain,
        range: [0, innerWidth],
        nice: true,
      }),
    [innerWidth, dependentAxis.domain],
  )
  const colorScale = scaleOrdinal<string, string>({
    domain: dataRender.categories,
    range: colors,
  })
  independentScale.rangeRound([0, innerWidth])
  dependentScale.range([innerHeight, 0])

  // GET SHARED LAYOUT PROPS
  const {
    dependentAxisProps,
    independentAxisProps,
    dependentGridProps,
    independentGridProps,
    ariaProps,
    legendProps,
    tooltipVisible,
    labelProps,
  } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A stacked column chart',
        config,
        data: flattenedData,
        size,
        tableData,
        dependentScale,
        independentScale,
      }),
    [config, flattenedData, size, tableData, dependentScale, independentScale],
  )

  const {
    tooltipOpen,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipData,
    hideTooltip,
    showTooltip,
  } = useTooltip<FlatData>()

  let tooltipTimeout: number

  return chartWidth && chartWidth < 100 ? null : (
    <div style={{ position: 'relative' }}>
      <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
        <Group top={padding.top} left={padding.left} role='presentation'>
          <GridRows {...dependentGridProps} />
          <GridColumns {...independentGridProps} />
          <BarStack
            data={flattenedData}
            keys={dataRender.categories}
            x={getIndependentValue}
            xScale={independentScale}
            yScale={dependentScale}
            color={colorScale}
          >
            {barStacks =>
              barStacks.map(barStack => {
                return barStack.bars.map(bar => {
                  const category: string = bar.key
                  const barData: FlatData = bar.bar['data']
                  const barValue: number =
                    barData[category as keyof typeof barData]
                  const customLabel: string = barData['__labels']?.[category]
                    ? barData['__labels']?.[category]
                    : ''
                  const customTooltip: string = barData['__tooltips']?.[
                    category
                  ]
                    ? barData['__tooltips']?.[category]
                    : ''
                  return (
                    <g
                      key={`barstack-vertical-${barStack.index}-${bar.index}-g`}
                    >
                      <rect
                        key={`barstack-vertical-${barStack.index}-${bar.index}`}
                        x={bar.x}
                        y={bar.y}
                        width={bar.width}
                        height={bar.height}
                        fill={bar.color}
                        tabIndex={0}
                        stroke={
                          barConfig.hasRectStroke
                            ? barConfig.rectStrokeColor
                            : 'none'
                        }
                        strokeWidth={
                          barConfig.hasRectStroke
                            ? barConfig.rectStrokeWidth
                            : '0'
                        }
                        fillOpacity={
                          tooltipData &&
                          tooltipVisible &&
                          tooltip.deemphasizeSiblings &&
                          (tooltipData?.x !== barData.x ||
                            tooltipData?.y !== barValue ||
                            tooltipData?.category !== category)
                            ? tooltip.deemphasizeOpacity
                            : 1
                        }
                        onMouseLeave={() => {
                          tooltipTimeout = window.setTimeout(() => {
                            hideTooltip()
                          }, 300)
                        }}
                        onMouseMove={event => {
                          if (tooltipTimeout) clearTimeout(tooltipTimeout)
                          const eventSvgCoords = localPoint(event) || {
                            x: 0,
                            y: 0,
                          }
                          showTooltip({
                            tooltipData: {
                              x: barData.x,
                              y: barValue,
                              category,
                              tooltip: customTooltip,
                            },
                            tooltipTop: eventSvgCoords.y,
                            tooltipLeft: eventSvgCoords.x,
                          })
                        }}
                        onFocus={() => {
                          if (tooltipTimeout) clearTimeout(tooltipTimeout)
                          showTooltip({
                            tooltipData: {
                              x: barData.x,
                              y: barValue,
                              category,
                              tooltip: customTooltip,
                            },
                            tooltipTop: bar.y,
                            tooltipLeft: bar.x,
                          })
                        }}
                        onBlur={() => {
                          tooltipTimeout = window.setTimeout(() => {
                            hideTooltip()
                          }, 300)
                        }}
                      />
                      {barValue && labels.active && labelCutoff < barValue && (
                        <text
                          key={`barstack-horizontal-label-${barStack.index}-${bar.index}`}
                          {...labelProps}
                          {...positionBarLabel(
                            {
                              x: bar.x,
                              y: bar.y,
                              width: bar.width,
                              height: bar.height,
                              value: barValue,
                            },
                            labels,
                            labelCutoff,
                            'vertical',
                            'stacked',
                          )}
                          fill={labelFill(bar.color)}
                          fillOpacity={
                            tooltipData &&
                            tooltipVisible &&
                            tooltip.deemphasizeSiblings &&
                            (tooltipData?.x !== barData.x ||
                              tooltipData?.y !== barValue ||
                              tooltipData?.category !== category)
                              ? tooltip.deemphasizeOpacity
                              : 1
                          }
                        >
                          {customLabel
                            ? customLabel
                            : `${getLabelFormat(
                                barValue,
                                category,
                                labels,
                                null,
                              )}`}
                        </text>
                      )}
                    </g>
                  )
                })
              })
            }
          </BarStack>
          {config.dependentAxis.active && <AxisLeft {...dependentAxisProps} />}
          {config.independentAxis.active && (
            <AxisBottom {...independentAxisProps} top={innerHeight} />
          )}
        </Group>
      </svg>
      {legend.active && (
        <StyledLegend legend={legend} theme={theme}>
          <LegendOrdinal
            {...legendProps}
            scale={colorScale}
            domain={
              legend.categories.length > 0
                ? legend.categories
                : colorScale.domain()
            }
          />
        </StyledLegend>
      )}

      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: getIndependentValue(tooltipData),
                      category: tooltipData.category,
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData.tooltip
                ? tooltipData.tooltip
                : getTooltipFormat(
                    {
                      x: getIndependentValue(tooltipData),
                      y: getDependentValue(tooltipData),
                      category: tooltipData.category,
                      color: colorScale(tooltipData.category || ''),
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default StackedBarVertical
