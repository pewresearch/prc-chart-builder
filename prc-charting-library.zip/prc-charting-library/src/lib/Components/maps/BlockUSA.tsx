import { CSSProperties, useCallback, useContext, useMemo, useRef } from 'react'
import states from '../../maps/usa/heatmap.json'

import type { BaseConfig } from '../../ts/types/configTypes'
import type { Size } from '../../ts/types/windowSize'
import { FlatData } from '../../ts/types/flatData'
import type { TableData } from '../../ts/types/tableData'

import { DataContext } from '../../Utilities/DataContext'
import { labelFill, useSize } from '../../Utilities'
import {
  getChartDimensions,
  getTooltipHeaderFormat,
  getTooltipFormat,
  getSharedProps,
} from '../shared'

import { Group } from '@visx/group'
import { scaleLinear, scaleOrdinal, scaleThreshold } from '@visx/scale'
import { HeatmapRect } from '@visx/heatmap'
import { localPoint } from '@visx/event'
import { useTooltip } from '@visx/tooltip'
import { StyledTooltip, StyledLegend } from '../index'
import { LegendLinear, LegendOrdinal, LegendThreshold } from '@visx/legend'
import { EventType } from '@visx/event/lib/types'

export type HeatmapProps = {
  width: number
  height: number
  margin?: { top: number; right: number; bottom: number; left: number }
  separation?: number
  events?: boolean
}

const BlockUSA = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }

  const { layout, colors, dataRender, labels, legend, tooltip } = config
  // SIZE AND LAYOUT
  const { height, width, theme, parentClass, padding } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)

  const { chartWidth, innerWidth, innerHeight, overflow } = getChartDimensions(
    size,
    layout,
  ) // bounds
  const mergedData = useMemo(() => {
    // using states, loop thorugh each bin, and each bin, loop through bins, cehck if bin name is in data, if it is, merge data into bin
    return states.map(column => {
      return {
        ...column,
        bins: column.bins.map(bin => {
          const binData = data.find(
            (d: { x: string | null; FIPS: string | null }) =>
              d.x === bin.name || d.FIPS === bin.fips,
          )
          return {
            ...bin,
            ...binData,
          }
        }),
      }
    })
  }, [data])

  const getDependentValue = useCallback(
    (d: FlatData) => d[dataRender.y] as number,
    [dataRender],
  )

  const getIndependentValue = useCallback(
    (d: FlatData) => d[dataRender.x] as string,
    [dataRender],
  )

  // TODO: i don't understand this magic number of 13.5
  const binWidth = width / 13.5
  const binHeight = binWidth
  const xScale = useMemo(
    () =>
      scaleLinear({
        domain: [0, 12.6],
        range: [0, innerWidth],
      }),
    [innerWidth],
  )

  const yScale = useMemo(
    () =>
      scaleLinear({
        domain: [0, 7.4],
        range: [0, innerHeight],
      }),
    [innerHeight],
  )

  const thresholdScale = scaleThreshold<number, string>({
    domain: dataRender.mapScaleDomain as number[],
    range: colors,
  })

  const ordinalScale = scaleOrdinal({
    domain: dataRender.mapScaleDomain as string[],
    range: colors,
  })

  const linearScale = scaleLinear({
    domain: dataRender.mapScaleDomain as number[],
    range: colors,
  })

  const getFill = (id: number | string, data: any, category: string) => {
    if (!id) return 'transparent'
    if (!data?.[category]) return '#d7d7d7'
    if (dataRender.mapScale === 'linear') {
      return linearScale(data?.[category])
    }
    if (dataRender.mapScale === 'ordinal') {
      return ordinalScale(data?.[category])
    }
    return thresholdScale(data?.[category])
  }

  // GET SHARED LAYOUT PROPS
  const { ariaProps, legendProps, tooltipVisible, labelProps } = useMemo(
    () =>
      getSharedProps({
        chartType:
          'A map of the United States, with each state represented as a block',
        config,
        data: mergedData,
        size,
        tableData,
      }),
    [config, mergedData, size, tableData],
  )

  const {
    tooltipData,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip<FlatData>()
  let tooltipTimeout: number

  return (
    <div
      style={{
        position: 'relative',
        overflowX: overflow as CSSProperties['overflowX'],
      }}
    >
      <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
        <Group top={padding.top} left={padding.left} role='presentation'>
          <HeatmapRect
            data={mergedData}
            xScale={xScale}
            yScale={yScale}
            binWidth={binWidth}
            binHeight={binHeight}
            gap={0}
          >
            {heatmap => {
              return heatmap.map(heatmapBins =>
                heatmapBins.map(
                  (bin: {
                    bin: any
                    row: number
                    column: number
                    width: number
                    height: number
                    x: number
                    y: number
                  }) => {
                    const { row, column, width, height, x, y, bin: data } = bin
                    const { id } = data
                    if (!id) return null

                    const category = dataRender.categories[0]
                    const fill = getFill(id, data, category)
                    const onMouseMove = (event: Element | EventType) => {
                      if (data[category] === undefined) return
                      if (tooltipTimeout) clearTimeout(tooltipTimeout)
                      const eventSvgCoords = localPoint(event) || {
                        x: 0,
                        y: 0,
                      }
                      showTooltip({
                        tooltipData: {
                          x: data.name,
                          id: data.id,
                          y: data[category],
                          category,
                          fill: fill,
                        },
                        tooltipTop: eventSvgCoords.y,
                        tooltipLeft: eventSvgCoords.x,
                      })
                    }
                    const onMouseLeave = () => {
                      tooltipTimeout = window.setTimeout(() => {
                        hideTooltip()
                      }, 300)
                    }

                    return (
                      <>
                        <rect
                          key={`heatmap-rect-${row}-${column}`}
                          className='visx-heatmap-rect'
                          width={width}
                          height={height}
                          x={x}
                          y={y}
                          stroke={id ? '#d7d7d7' : 'transparent'}
                          opacity={
                            tooltipData &&
                            tooltipVisible &&
                            tooltipData?.id === id
                              ? 0.8
                              : 1
                          }
                          fill={fill}
                          tabIndex={0}
                          // onClick={events => {
                          //   if (!events) return
                          //   const { row, column } = bin
                          //   alert(JSON.stringify({ row, column, bin: bin.bin }))
                          // }}
                          onMouseLeave={onMouseLeave}
                          onMouseMove={onMouseMove}
                          onBlur={onMouseLeave}
                          onFocus={onMouseMove}
                        />
                        {labels.active && (
                          <text
                            {...labelProps}
                            dy={labels.labelPositionDY}
                            dx={labels.labelPositionDX}
                            x={x}
                            y={y}
                            fill={labelFill(fill)}
                            onMouseLeave={onMouseLeave}
                            onMouseMove={onMouseMove}
                          >
                            {id}
                          </text>
                        )}
                      </>
                    )
                  },
                ),
              )
            }}
          </HeatmapRect>
        </Group>
      </svg>
      {legend.active && (
        <StyledLegend legend={legend} theme={theme}>
          {dataRender.mapScale === 'threshold' && (
            <LegendThreshold
              {...legendProps}
              scale={thresholdScale}
              labelLower={legend.labelLower}
              labelUpper={legend.labelUpper}
              labelDelimiter={legend.labelDelimiter}
            />
          )}
          {dataRender.mapScale === 'ordinal' && (
            <LegendOrdinal
              {...legendProps}
              scale={ordinalScale}
              domain={
                legend.categories.length > 0
                  ? legend.categories
                  : ordinalScale.domain()
              }
            />
          )}
          {dataRender.mapScale === 'linear' && (
            <LegendLinear {...legendProps} scale={linearScale} />
          )}
        </StyledLegend>
      )}
      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: tooltipData.x,
                      category: tooltipData.category,
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData.customTooltip
                ? tooltipData.customTooltip
                : getTooltipFormat(
                    {
                      x: tooltipData.x,
                      y: tooltipData.y,
                      category: tooltipData.category,
                      color: tooltipData.fill,
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default BlockUSA
