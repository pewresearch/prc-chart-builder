// External Imports
import {
  useState,
  Fragment,
  useContext,
  useMemo,
  useRef,
  CSSProperties,
} from 'react'
import { geoRobinson } from 'd3-geo-projection'
import * as topojson from 'topojson-client'

//Visx Imports
import { CustomProjection } from '@visx/geo'
import { geoCentroid } from '@visx/vendor/d3-geo'
import { scaleThreshold, scaleOrdinal, scaleLinear } from '@visx/scale'
import { LegendThreshold, LegendOrdinal, LegendLinear } from '@visx/legend'
import { useTooltip } from '@visx/tooltip'
import { localPoint } from '@visx/event'
import { EventType } from '@visx/event/lib/types'
import { Zoom } from '@visx/zoom'
// Local Imports
import topology from '../../maps/world/countries-50m.json'
import { DataContext } from '../../Utilities/DataContext'
import { BaseConfig } from '../../ts/types/configTypes'
import { useSize, labelFill } from '../../Utilities'
import {
  getChartDimensions,
  getLabelProps,
  getTooltipFormat,
  getTooltipHeaderFormat,
  getTooltipVisible,
  getLegendProps,
  getSharedProps,
} from '../shared'
import { StyledTooltip, StyledLegend } from '../index'
// Types
import type { Size } from '../../ts/types/windowSize'
import type { FlatData } from '../../ts/types/flatData'
import type { FeatureShape } from '../../ts/types/featureShape'
import type { TableData } from '../../ts/types/tableData'
import { Group } from '@visx/group'
// @ts-expect-error
const { features: world } = topojson.feature(
  //@ts-expect-error
  topology,
  topology.objects.countries,
) as {
  type: 'FeatureCollection'
  features: FeatureShape[]
}

// @ts-expect-error
const geojson = topojson.feature(topology, topology.objects.countries)

const projection = geoRobinson

const World = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }
  const [isUnZoomed, setIsUnZoomed] = useState(true)
  const { layout, colors, dataRender, labels, legend, tooltip, map } = config
  // SIZE AND LAYOUT
  const { height, width, theme, parentClass, padding } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)

  const { chartWidth, innerWidth, innerHeight, overflow } = getChartDimensions(
    size,
    layout,
  )
  const flattenedData = useMemo(
    () =>
      data.reduce((acc: string | any[], curr: any) => {
        return acc.concat(curr)
      }, []),
    [data],
  )
  // DATA ACCESSORS
  const getIndependentValue = (d: FlatData) => d[dataRender.x].toString()
  const getDependentValue = (d: FlatData) => d[dataRender.y] as number | string
  // using unitedStates, loop through each state and check if the state is in the flattenedData array,
  // if it is, merge that data into the state's properties object
  const mergedData = useMemo(() => {
    return world.map(country => {
      const countryName = country.properties.name
      const countryId = country.id
      const countryData = flattenedData.find(
        (d: any) => d.x === countryName || d.ISO === countryId,
      )
      return {
        ...country,
        properties: {
          ...country.properties,
          ...countryData,
        },
      }
    })
  }, [world, flattenedData])

  const mergedAndFilteredData = useMemo(() => {
    return mergedData.filter(
      county => county.properties?.[dataRender.categories[0]],
    )
  }, [mergedData, dataRender.categories])

  const thresholdScale = scaleThreshold<number, string>({
    domain: dataRender.mapScaleDomain as number[],
    range: colors,
  })

  const ordinalScale = scaleOrdinal({
    domain: dataRender.mapScaleDomain as string[],
    range: colors,
  })

  const linearScale = scaleLinear({
    domain: dataRender.mapScaleDomain as number[],
    range: colors,
  })

  const getFill = (id: number | string, data: any, category: string) => {
    if (!id) return 'transparent'
    if (!data?.[category]) return '#d7d7d7'
    if (dataRender.mapScale === 'linear') {
      return linearScale(data?.[category])
    }
    if (dataRender.mapScale === 'ordinal') {
      return ordinalScale(data?.[category])
    }
    return thresholdScale(data?.[category])
  }

  const centerX = chartWidth / 2
  const centerY = height / 2
  const scaleX = geoRobinson().fitWidth(chartWidth, geojson)
  const scaleY = geoRobinson().fitHeight(height, geojson)
  const initialScale = (chartWidth / height) * 50

  // GET SHARED LAYOUT PROPS
  const { ariaProps, legendProps, tooltipVisible, labelProps } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A map of the world',
        config,
        data: flattenedData,
        size,
        tableData,
      }),
    [config, flattenedData, size, tableData],
  )

  // TOOLTIP AND HANDLERS
  const {
    tooltipData,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip<FlatData>()
  let tooltipTimeout: number

  return (
    <Zoom<SVGSVGElement>
      width={chartWidth}
      height={height}
      scaleXMin={100}
      scaleXMax={1000}
      scaleYMin={100}
      scaleYMax={1000}
      initialTransformMatrix={{
        scaleX: initialScale,
        scaleY: initialScale + 100,
        translateX: centerX,
        translateY: centerY - 25,
        skewX: 0,
        skewY: 0,
      }}
    >
      {zoom => (
        <div
          style={{
            position: 'relative',
            // overflow: 'hidden',
            overflowX: overflow as CSSProperties['overflowX'],
          }}
        >
          <svg
            width={chartWidth}
            height={height}
            ref={map.zoomActive ? zoom.containerRef : svgRef}
            className={zoom.isDragging ? 'dragging' : undefined}
            style={{ touchAction: 'none' }}
            {...ariaProps}
          >
            <Group role='presentation' top={padding.top} left={padding.left}>
              <CustomProjection<FeatureShape>
                projection={projection}
                data={mergedData}
                scale={zoom.transformMatrix.scaleX}
                fitSize={
                  isUnZoomed
                    ? [[innerWidth, innerHeight + 100], geojson]
                    : undefined
                }
                translate={
                  map.zoomActive
                    ? [
                        zoom.transformMatrix.translateX,
                        zoom.transformMatrix.translateY,
                      ]
                    : [centerX, centerY - 25]
                }
              >
                {({ features }) =>
                  features.map(({ feature, path }, i) => {
                    const { id } = feature
                    if (!id) {
                      return
                    }
                    //filter out Antarctica
                    if (id === '010') {
                      return
                    }

                    return (
                      <Fragment key={`map-feature-${i}`}>
                        <path
                          key={`map-feature-${i}`}
                          d={path || ''}
                          fill={map.pathBackgroundFill}
                          stroke={map.pathStroke}
                          strokeWidth={0.5}
                        />
                      </Fragment>
                    )
                  })
                }
              </CustomProjection>
              <CustomProjection<FeatureShape>
                projection={projection}
                data={mergedAndFilteredData}
                scale={zoom.transformMatrix.scaleX}
                fitSize={
                  isUnZoomed
                    ? [[innerWidth, innerHeight + 100], geojson]
                    : undefined
                }
                translate={
                  map.zoomActive
                    ? [
                        zoom.transformMatrix.translateX,
                        zoom.transformMatrix.translateY,
                      ]
                    : [centerX, centerY - 25]
                }
              >
                {({ features }) =>
                  features.map(({ feature, path, projection }, i) => {
                    const coords: [number, number] | null = projection(
                      geoCentroid(feature),
                    )
                    const { id, properties } = feature
                    if (!coords || !id) {
                      return
                    }
                    const category = dataRender.categories[0]
                    const fill = getFill(id, properties, category)
                    const onMouseMove = (event: Element | EventType) => {
                      if (tooltipTimeout) clearTimeout(tooltipTimeout)
                      const eventSvgCoords = localPoint(event) || {
                        x: 0,
                        y: 0,
                      }
                      showTooltip({
                        tooltipData: {
                          x: feature.properties.name,
                          id: feature.id,
                          y: feature.properties[dataRender.categories[0]],
                          category,
                          fill: fill,
                        },
                        tooltipTop: eventSvgCoords.y,
                        tooltipLeft: eventSvgCoords.x,
                      })
                    }
                    const onMouseLeave = () => {
                      tooltipTimeout = window.setTimeout(() => {
                        hideTooltip()
                      }, 300)
                    }

                    return (
                      <Fragment key={`map-feature-${i}`}>
                        <path
                          key={`map-feature-${i}`}
                          d={path || ''}
                          fill={fill}
                          stroke={map.pathStroke}
                          strokeWidth={0.5}
                          tabIndex={0}
                          onBlur={onMouseLeave}
                          onFocus={onMouseMove}
                          onMouseLeave={onMouseLeave}
                          onMouseMove={onMouseMove}
                          onTouchStart={() => {
                            if (!map.zoomActive) return
                            setIsUnZoomed(false)
                            zoom.dragStart
                          }}
                          onTouchMove={() => {
                            if (!map.zoomActive) return
                            setIsUnZoomed(false)
                            zoom.dragMove
                          }}
                          onTouchEnd={() => {
                            if (!map.zoomActive) return
                            setIsUnZoomed(false)
                            zoom.dragEnd
                          }}
                          onMouseDown={() => {
                            if (!map.zoomActive) return
                            setIsUnZoomed(false)
                            zoom.dragStart
                          }}
                          // onMouseMove={zoom.dragMove}
                          onMouseUp={() => {
                            if (!map.zoomActive) return
                            setIsUnZoomed(false)
                            zoom.dragEnd
                          }}
                        />
                        {/* TODO: figure out if we even want to include labels for world map */}
                        {/* {labels.active && !ignoredStates.includes(abbr) && (
                    <text
                      {...getLabelProps(labels)}
                      transform={null !== coords ? `translate(${coords})` : ''}
                      dy={labels.labelPositionDY}
                      dx={labels.labelPositionDX}
                      fill={abbr === 'HI' ? '#000' : labelFill(fill)}
                      onMouseMove={onMouseMove}
                      onMouseLeave={onMouseLeave}
                    >
                      {abbr}
                    </text>
                  )} */}
                      </Fragment>
                    )
                  })
                }
              </CustomProjection>
            </Group>
            {/* <rect
              x={0}
              y={0}
              width={chartWidth}
              height={height}
              fill='transparent'
              onTouchStart={zoom.dragStart}
              onTouchMove={zoom.dragMove}
              onTouchEnd={zoom.dragEnd}
              onMouseDown={zoom.dragStart}
              // onMouseMove={zoom.dragMove}
              onMouseUp={zoom.dragEnd}
              // onMouseLeave={() => {
              //   if (zoom.isDragging) zoom.dragEnd()
              // }}
            /> */}
          </svg>
          {map.zoomActive && (
            <>
              <div
                className='controls'
                style={{
                  position: 'absolute',
                  bottom: '10px',
                  right: '10px',
                  zIndex: 1000,
                }}
              >
                <button
                  className='button'
                  onClick={() => {
                    setIsUnZoomed(false)
                    zoom.scale({ scaleX: 1.2, scaleY: 1.2 })
                  }}
                >
                  +
                </button>
                <button
                  className='button'
                  onClick={() => {
                    setIsUnZoomed(false)
                    zoom.scale({ scaleX: 0.8, scaleY: 0.8 })
                  }}
                >
                  -
                </button>
                <button
                  className='button'
                  onClick={() => {
                    setIsUnZoomed(true)
                    zoom.reset
                  }}
                >
                  Reset
                </button>
              </div>
            </>
          )}
          {legend.active && (
            <StyledLegend legend={legend} theme={theme}>
              {dataRender.mapScale === 'threshold' && (
                <LegendThreshold
                  {...legendProps}
                  scale={thresholdScale}
                  labelLower={legend.labelLower}
                  labelUpper={legend.labelUpper}
                  labelDelimiter={legend.labelDelimiter}
                />
              )}
              {dataRender.mapScale === 'ordinal' && (
                <LegendOrdinal
                  {...legendProps}
                  scale={ordinalScale}
                  domain={
                    legend.categories.length > 0
                      ? legend.categories
                      : ordinalScale.domain()
                  }
                />
              )}
              {dataRender.mapScale === 'linear' && (
                <LegendLinear {...legendProps} scale={linearScale} />
              )}
            </StyledLegend>
          )}
          {tooltipOpen && tooltipData && tooltipVisible && (
            <StyledTooltip
              top={tooltipTop}
              left={tooltipLeft}
              tooltip={tooltip}
              theme={theme}
            >
              <>
                {tooltip.headerActive && (
                  <div
                    style={{
                      marginBottom: '10px',
                    }}
                  >
                    <strong>
                      {getTooltipHeaderFormat(
                        {
                          x: tooltipData.x,
                          category: tooltipData.category,
                        },
                        tooltip,
                      )}
                    </strong>
                  </div>
                )}
              </>
              <div
                dangerouslySetInnerHTML={{
                  __html: tooltipData.customTooltip
                    ? tooltipData.customTooltip
                    : getTooltipFormat(
                        {
                          x: tooltipData.x,
                          y: tooltipData.y,
                          category: tooltipData.key,
                          color: tooltipData.fill,
                        },
                        tooltip,
                        dataRender,
                      ),
                }}
              />
            </StyledTooltip>
          )}
        </div>
      )}
    </Zoom>
  )
}

export default World
