// REACT
import {
  useState,
  Fragment,
  useContext,
  useMemo,
  useRef,
  CSSProperties,
} from 'react'

// VISX
import { AlbersUsa } from '@visx/geo'
import { geoCentroid } from '@visx/vendor/d3-geo'
import { scaleThreshold, scaleOrdinal, scaleLinear } from '@visx/scale'
import { LegendThreshold, LegendOrdinal, LegendLinear } from '@visx/legend'
import { useTooltip } from '@visx/tooltip'
import { localPoint } from '@visx/event'
import { EventType } from '@visx/event/lib/types'
import { Group } from '@visx/group'

// TYPES
import { BaseConfig } from '../../ts/types/configTypes'
import { Size } from '../../ts/types/windowSize'
import { FlatData } from '../../ts/types/flatData'
import { FeatureShape } from '../../ts/types/featureShape'
import { TableData } from '../../ts/types/tableData'

import * as topojson from 'topojson-client'
// INTERNAL
import topology from '../../maps/usa/topology.json'
import stateAbbrs from '../../maps/usa/abbreviations.json'
import { DataContext } from '../../Utilities/DataContext'
import { useSize, labelFill } from '../../Utilities'
import {
  getChartDimensions,
  getLabelProps,
  getTooltipFormat,
  getTooltipHeaderFormat,
  getTooltipVisible,
  getLegendProps,
  getSharedProps,
} from '../shared'
import { StyledTooltip, StyledLegend } from '../index'

// @ts-expect-error
const { features: unitedStates } = topojson.feature(
  // @ts-expect-error
  topology,
  topology.objects.states,
) as {
  type: 'FeatureCollection'
  features: FeatureShape[]
}

// @ts-expect-error
const geojson = topojson.feature(topology, topology.objects.states)

// X and Y adjustments to individual states
const coordOffsets: Record<string, number[]> = {
  FL: [11, 3],
  AK: [0, -4],
  CA: [-7, 0],
  NY: [5, 0],
  MI: [13, 20],
  LA: [-10, -3],
  HI: [-10, 10],
  ID: [0, 10],
  WV: [-2, 4],
  KY: [10, 0],
  TN: [0, 4],
}

/**
 * These states are too small to have text labels
 * inside of them and are usually displayed with pointers.
 * TODO: add a pointer for these states in the future
 */
const ignoredStates: string[] = ['VT', 'NH', 'MA', 'RI', 'CT', 'NJ', 'DE', 'MD']

const AlbersUSA = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }

  const { layout, colors, dataRender, labels, legend, tooltip, map } = config
  // SIZE AND LAYOUT
  const { height, theme, parentClass, padding } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)

  const { chartWidth, innerWidth, innerHeight, overflow } = getChartDimensions(
    size,
    layout,
  )
  const flattenedData = useMemo(
    () =>
      data.reduce((acc: string | any[], curr: any) => {
        return acc.concat(curr)
      }, []),
    [data],
  )
  // DATA ACCESSORS
  const getIndependentValue = (d: FlatData) => d[dataRender.x].toString()
  const getDependentValue = (d: FlatData) => d[dataRender.y] as number | string
  // using unitedStates, loop through each state and check if the state is in the flattenedData array,
  // if it is, merge that data into the state's properties object
  const mergedData = useMemo(
    () =>
      unitedStates.map(state => {
        const stateName = state.properties.name
        const stateFIPS = state.id
        const stateData = flattenedData.find(
          (d: any) => d.x === stateName || d.x === stateFIPS,
        )
        return {
          ...state,
          properties: {
            ...state.properties,
            ...stateData,
          },
        }
      }),
    [flattenedData],
  )

  const thresholdScale = scaleThreshold<number, string>({
    domain: dataRender.mapScaleDomain as number[],
    range: colors,
  })

  const ordinalScale = scaleOrdinal({
    domain: dataRender.mapScaleDomain as string[],
    range: colors,
  })

  const linearScale = scaleLinear({
    domain: dataRender.mapScaleDomain as number[],
    range: colors,
  })

  const getFill = (id: number | string, data: any, category: string) => {
    if (!id) return 'transparent'
    if (!data?.[category]) return map.pathBackgroundFill
    if (dataRender.mapScale === 'linear') {
      return linearScale(data?.[category])
    }
    if (dataRender.mapScale === 'ordinal') {
      return ordinalScale(data?.[category])
    }
    return thresholdScale(data?.[category])
  }

  const centerX = chartWidth / 2
  const centerY = height / 2
  const scale = (chartWidth + height) / 1.55

  // GET SHARED LAYOUT PROPS
  const { ariaProps, legendProps, tooltipVisible, labelProps } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A map of the United States',
        config,
        data: flattenedData,
        size,
        tableData,
      }),
    [config, flattenedData, size, tableData],
  )

  // TOOLTIP AND HANDLERS
  const {
    tooltipData,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip<FlatData>()
  let tooltipTimeout: number

  return (
    <div
      style={{
        position: 'relative',
        overflowX: overflow as CSSProperties['overflowX'],
      }}
    >
      <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
        <Group role='presentation' top={padding.top} left={padding.left}>
          <AlbersUsa<FeatureShape>
            data={mergedData}
            fitSize={[[innerWidth, innerHeight], geojson]}
            translate={[centerX, centerY - 25]}
          >
            {({ features }) =>
              features.map(({ feature, path, projection }, i) => {
                const coords: [number, number] | null = projection(
                  geoCentroid(feature),
                )
                const { id, properties } = feature
                if (!coords || !id) {
                  return
                }
                // @ts-expect-error
                const abbr: string = stateAbbrs[feature.id]
                if (coordOffsets[abbr] && coords) {
                  coords[0] += coordOffsets[abbr][0]
                  coords[1] += coordOffsets[abbr][1]
                }
                const category = dataRender.categories[0]
                const fill = getFill(id, properties, category)
                const onMouseMove = (event: Element | EventType) => {
                  if (tooltipTimeout) clearTimeout(tooltipTimeout)
                  const eventSvgCoords = localPoint(event) || {
                    x: 0,
                    y: 0,
                  }
                  showTooltip({
                    tooltipData: {
                      x: feature.properties.name,
                      id: feature.id,
                      y: feature.properties[dataRender.categories[0]],
                      category,
                      fill: fill,
                    },
                    tooltipTop: eventSvgCoords.y,
                    tooltipLeft: eventSvgCoords.x,
                  })
                }
                const onMouseLeave = () => {
                  tooltipTimeout = window.setTimeout(() => {
                    hideTooltip()
                  }, 300)
                }

                return (
                  <Fragment key={`map-feature-${i}`}>
                    <path
                      key={`map-feature-${i}`}
                      d={path || ''}
                      fill={fill}
                      stroke={map.pathStroke}
                      strokeWidth={0.5}
                      tabIndex={0}
                      onMouseLeave={onMouseLeave}
                      onMouseMove={onMouseMove}
                      onFocus={onMouseMove}
                      onBlur={onMouseLeave}
                    />
                    {labels.active && !ignoredStates.includes(abbr) && (
                      <text
                        {...labelProps}
                        transform={
                          null !== coords ? `translate(${coords})` : ''
                        }
                        dy={labels.labelPositionDY}
                        dx={labels.labelPositionDX}
                        fill={abbr === 'HI' ? '#000' : labelFill(fill)}
                        onMouseMove={onMouseMove}
                        onMouseLeave={onMouseLeave}
                      >
                        {abbr}
                      </text>
                    )}
                  </Fragment>
                )
              })
            }
          </AlbersUsa>
        </Group>
      </svg>
      {legend.active && (
        <StyledLegend legend={legend} theme={theme}>
          {dataRender.mapScale === 'threshold' && (
            <LegendThreshold
              {...legendProps}
              scale={thresholdScale}
              labelLower={legend.labelLower}
              labelUpper={legend.labelUpper}
              labelDelimiter={legend.labelDelimiter}
            />
          )}
          {dataRender.mapScale === 'ordinal' && (
            <LegendOrdinal
              {...legendProps}
              scale={ordinalScale}
              domain={
                legend.categories.length > 0
                  ? legend.categories
                  : ordinalScale.domain()
              }
            />
          )}
          {dataRender.mapScale === 'linear' && (
            <LegendLinear {...legendProps} scale={linearScale} />
          )}
        </StyledLegend>
      )}
      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: tooltipData.x,
                      category: tooltipData.category,
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData.customTooltip
                ? tooltipData.customTooltip
                : getTooltipFormat(
                    {
                      x: tooltipData.x,
                      y: tooltipData.y,
                      category: tooltipData.key,
                      color: tooltipData.fill,
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default AlbersUSA
