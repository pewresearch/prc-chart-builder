import {
  useState,
  Fragment,
  useContext,
  useMemo,
  useRef,
  CSSProperties,
} from 'react'

import * as topojson from 'topojson-client'
import topology from '../../maps/usa-counties/topology.json'
import stateAbbrs from '../../maps/usa/abbreviations.json'
import { DataContext } from '../../Utilities/DataContext'
import { useSize } from '../../Utilities'
import { Size } from '../../ts/types/windowSize'
import {
  getChartDimensions,
  getTooltipHeaderFormat,
  getTooltipFormat,
  getSharedProps,
} from '../shared'
import { StyledTooltip, StyledLegend } from '../index'

// Types
import { FlatData } from '../../ts/types/flatData'
import { FeatureShape } from '../../ts/types/featureShape'
import { BaseConfig } from '../../ts/types/configTypes'
import { TableData } from '../../ts/types/tableData'

// Visx
import { AlbersUsa } from '@visx/geo'
import { geoCentroid } from '@visx/vendor/d3-geo'
import { scaleLinear, scaleOrdinal, scaleThreshold } from '@visx/scale'
import { localPoint } from '@visx/event'
import { useTooltip } from '@visx/tooltip'
import { EventType } from '@visx/event/lib/types'
import { Group } from '@visx/group'
import { LegendLinear, LegendOrdinal, LegendThreshold } from '@visx/legend'

// @ts-expect-error
const { features: usCounties } = topojson.feature(
  // @ts-expect-error
  topology,
  topology.objects.counties,
) as {
  type: 'FeatureCollection'
  features: FeatureShape[]
}

const { features: usStates } = topojson.feature(
  // @ts-expect-error
  topology,
  topology.objects.states,
) as unknown as {
  type: 'FeatureCollection'
  features: FeatureShape[]
}
// geojson object for creating scale
// @ts-expect-error
const geojson = topojson.feature(topology, topology.objects.states)

// X and Y adjustments to individual states
const coordOffsets: Record<string, number[]> = {
  FL: [11, 3],
  AK: [0, -4],
  CA: [-7, 0],
  NY: [5, 0],
  MI: [13, 20],
  LA: [-10, -3],
  HI: [-10, 10],
  ID: [0, 10],
  WV: [-2, 4],
  KY: [10, 0],
  TN: [0, 4],
}

/**
 * These states are too small to have text labels
 * inside of them and are usually displayed with pointers.
 * For simplicity they are omitted from this demo.
 */
const ignoredStates = ['VT', 'NH', 'MA', 'RI', 'CT', 'NJ', 'DE', 'MD']
const AlbersUSACounties = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }

  const { layout, colors, dataRender, map, labels, legend, tooltip } = config
  // SIZE AND LAYOUT
  const { padding, parentClass, height, width, theme } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)

  const { chartWidth, innerWidth, innerHeight, overflow } = getChartDimensions(
    size,
    layout,
  )
  const flattenedData = useMemo(
    () =>
      data.reduce((acc: string | any[], curr: any) => {
        return acc.concat(curr)
      }, []),
    [data],
  )
  // using usCounties, loop through each state and check if the state is in the flattenedData array,
  // if it is, merge that data into the state's properties object
  const mergedData = useMemo(() => {
    return usCounties.map(county => {
      const countyFIPS = county.id
      const countyData = flattenedData.find(
        (d: any) => d.x === countyFIPS || d.FIPS === countyFIPS,
      )
      return {
        ...county,
        properties: {
          ...county.properties,
          ...countyData,
        },
      }
    })
  }, [usCounties, flattenedData])

  // filter out any data that doesn't have d.FIPS === county.id
  const mergedAndFilteredData = useMemo(() => {
    return mergedData.filter(
      county => county.properties?.[dataRender.categories[0]],
    )
  }, [mergedData, dataRender.categories])

  const thresholdScale = scaleThreshold<number, string>({
    domain: dataRender.mapScaleDomain as number[],
    range: colors,
  })

  const ordinalScale = scaleOrdinal({
    domain: dataRender.mapScaleDomain as string[],
    range: colors,
  })

  const linearScale = scaleLinear({
    domain: dataRender.mapScaleDomain as number[],
    range: colors,
  })

  const getFill = (id: number | string, data: any, category: string) => {
    if (!id) return 'transparent'
    if (!data?.[category]) return map.pathBackgroundFill
    if (dataRender.mapScale === 'linear') {
      return linearScale(data?.[category])
    }
    if (dataRender.mapScale === 'ordinal') {
      return ordinalScale(data?.[category])
    }
    return thresholdScale(data?.[category])
  }

  const centerX = chartWidth / 2
  const centerY = height / 2

  // GET SHARED LAYOUT PROPS
  const { ariaProps, legendProps, tooltipVisible, labelProps } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A map of the United State’s counties',
        config,
        data: flattenedData,
        size,
        tableData,
      }),
    [config, flattenedData, size, tableData],
  )

  // TOOLTIP AND HANDLERS
  const {
    tooltipData,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip<FlatData>()
  let tooltipTimeout: number

  return (
    <div
      style={{
        position: 'relative',
        overflowX: overflow as CSSProperties['overflowX'],
      }}
    >
      <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
        <Group role='presentation' top={padding.top} left={padding.left}>
          {map.showStateBoundaries && (
            <AlbersUsa<FeatureShape>
              data={usStates}
              fitSize={[[chartWidth, height], geojson]}
              translate={[centerX, centerY - 25]}
            >
              {/* Paths for State Boundaries */}
              {({ features }) =>
                features.map(({ feature, path, projection }, i) => {
                  const coords: [number, number] | null = projection(
                    geoCentroid(feature),
                  )
                  const { id } = feature
                  if (!coords || !id) {
                    return
                  }
                  return (
                    <Fragment key={`map-feature-${i}`}>
                      <path
                        key={`map-feature-${i}`}
                        d={path || ''}
                        fill={map.pathBackgroundFill}
                        stroke={map.pathStroke}
                        strokeWidth={1}
                      />
                    </Fragment>
                  )
                })
              }
            </AlbersUsa>
          )}
          {map.showCountyBoundaries && (
            <AlbersUsa<FeatureShape>
              data={usCounties}
              fitSize={[[chartWidth, height], geojson]}
              translate={[centerX, centerY - 25]}
            >
              {/* Paths for County Boundaries */}
              {({ features }) =>
                features.map(({ feature, path, projection }, i) => {
                  const coords: [number, number] | null = projection(
                    geoCentroid(feature),
                  )
                  const { id } = feature
                  if (!coords || !id) {
                    return
                  }
                  return (
                    <Fragment key={`map-feature-${i}`}>
                      <path
                        key={`map-feature-${i}`}
                        d={path || ''}
                        fill={map.pathBackgroundFill}
                        stroke={map.pathStroke}
                        strokeWidth={0.5}
                      />
                    </Fragment>
                  )
                })
              }
            </AlbersUsa>
          )}
          <AlbersUsa<FeatureShape>
            data={mergedAndFilteredData}
            fitSize={[[chartWidth, height], geojson]}
            translate={[centerX, centerY - 25]}
          >
            {({ features }) =>
              features.map(({ feature, path, projection }, i) => {
                const coords: [number, number] | null = projection(
                  geoCentroid(feature),
                )
                const { id, properties } = feature
                if (!coords || !id) {
                  return
                }
                const category = dataRender.categories[0]
                const fill = getFill(id, properties, category)
                const onMouseMove = (event: Element | EventType) => {
                  if (tooltipTimeout) clearTimeout(tooltipTimeout)
                  const eventSvgCoords = localPoint(event) || {
                    x: 0,
                    y: 0,
                  }
                  showTooltip({
                    tooltipData: {
                      x: feature.properties.name,
                      id: feature.id,
                      y: feature.properties[dataRender.categories[0]],
                      fill,
                      category,
                    },
                    tooltipTop: eventSvgCoords.y,
                    tooltipLeft: eventSvgCoords.x,
                  })
                }
                const onMouseLeave = () => {
                  tooltipTimeout = window.setTimeout(() => {
                    hideTooltip()
                  }, 300)
                }

                return (
                  <Fragment key={`map-feature-${i}`}>
                    <path
                      key={`map-feature-${i}`}
                      d={path || ''}
                      fill={fill}
                      stroke={map.pathStroke}
                      strokeWidth={0.5}
                      tabIndex={0}
                      onMouseMove={onMouseMove}
                      onMouseLeave={onMouseLeave}
                      onFocus={onMouseMove}
                      onBlur={onMouseLeave}
                    />
                  </Fragment>
                )
              })
            }
          </AlbersUsa>
        </Group>
      </svg>
      {legend.active && (
        <StyledLegend legend={legend} theme={theme}>
          {dataRender.mapScale === 'threshold' && (
            <LegendThreshold
              {...legendProps}
              scale={thresholdScale}
              labelLower={legend.labelLower}
              labelUpper={legend.labelUpper}
              labelDelimiter={legend.labelDelimiter}
            />
          )}
          {dataRender.mapScale === 'ordinal' && (
            <LegendOrdinal
              {...legendProps}
              scale={ordinalScale}
              domain={
                legend.categories.length > 0
                  ? legend.categories
                  : ordinalScale.domain()
              }
            />
          )}
          {dataRender.mapScale === 'linear' && (
            <LegendLinear {...legendProps} scale={linearScale} />
          )}
        </StyledLegend>
      )}
      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: tooltipData.x,
                      category: tooltipData.category,
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData.customTooltip
                ? tooltipData.customTooltip
                : getTooltipFormat(
                    {
                      x: tooltipData.x,
                      y: tooltipData.y,
                      category: tooltipData.category,
                      color: tooltipData.fill,
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default AlbersUSACounties
