import { Legend } from '../ts/types/configTypes'
type LegendProps = {
  children: React.ReactNode
  legend: Legend
  theme: 'dark' | 'light'
  layoutWidth?: number
  chartWidth?: number
}
export const StyledLegend = ({
  children,
  legend,
  theme,
  chartWidth,
  layoutWidth,
}: LegendProps) => {
  const { offsetX, offsetY, title, alignment } = legend
  const widthRatio = chartWidth && layoutWidth ? chartWidth / layoutWidth : 1
  return (
    <div
      style={{
        position: 'absolute',
        top: offsetY / 2 - 10,
        left: offsetX * widthRatio,
        width: alignment === 'none' ? 'auto' : '100%',
        display: alignment === 'none' ? 'block' : 'flex',
        justifyContent: alignment,
        fontSize: '12px',
        fontFamily: "'franklin-gothic-urw', Verdana, Geneva, sans-serif",
      }}
    >
      <div
        className='cb__legend__inner'
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          backgroundColor: theme === 'light' ? legend.fill : '#1e1e1e',
          border: legend.borderStroke
            ? `1px solid ${theme === 'light' ? legend.borderStroke : '#fff'}`
            : 'none',
          padding: '10px',
        }}
      >
        {title && (
          <div
            className='cb__legend__title'
            style={{
              fontSize: '12px',
              fontWeight: 400,
              marginBottom: '10px',
            }}
          >
            {title}
          </div>
        )}
        {children}
      </div>
    </div>
  )
}
