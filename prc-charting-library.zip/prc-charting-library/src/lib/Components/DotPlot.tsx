// TODO: add labels, add option to connect nodes
// INTERNAL
import { DataContext } from '../Utilities/DataContext'
import { useSize } from '../Utilities'
import {
  getAxisProps,
  getGridProps,
  getLabelProps,
  getLabelFormat,
  getTooltipFormat,
  getChartDimensions,
  getTooltipHeaderFormat,
  getTooltipVisible,
  getAria,
  getSharedProps,
} from './shared'
import { StyledLegend } from './Legend'
import { StyledTooltip } from './Tooltip'
import { DiffColumn } from './DiffColumn'

// TYPES
import type { FlatData } from '../ts/types/flatData'
import type { Size } from '../ts/types/windowSize'
import type { BaseConfig } from '../ts/types/configTypes'
import type { TableData } from '../ts/types/tableData'

// REACT
import { useCallback, useContext, useMemo, useRef } from 'react'

// VISX
import { Circle, Line } from '@visx/shape'
import { Group } from '@visx/group'
import { GridRows, GridColumns } from '@visx/grid'
import { AxisBottom, AxisLeft, AxisRight } from '@visx/axis'
import { scaleLinear, scalePoint, scaleOrdinal } from '@visx/scale'
import { useTooltip } from '@visx/tooltip'
import { Text } from '@visx/text'
import { LegendOrdinal } from '@visx/legend'

// OTHER LIBRARIES
import { ascending, descending } from 'd3-array'
import { min, max } from 'd3-array'
import styled from '@emotion/styled'

const md5Hash = require('md5-hash')

const StyledCircle = styled(Circle)`
  &:focus {
    outline: none;
  }
`

const DotPlot = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }
  const {
    dependentAxis,
    independentAxis,
    layout,
    colors,
    nodes,
    dataRender,
    tooltip,
    dotPlot,
    labels: labelConfig,
    legend,
    diffColumn,
  } = config

  // SIZE AND LAYOUT
  const { height, parentClass, padding, theme } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)
  const { chartWidth, innerWidth, innerHeight } = getChartDimensions(
    size,
    layout,
    diffColumn,
  )
  // DATA PROCESSING
  const flattenedData = data
    .reduce((acc: string | any[], curr: any) => {
      return acc.concat(curr)
    }, [])
    .map((row: any) => {
      return Object.keys(row).reduce((acc, key) => {
        const value =
          row[key] === '' || isNaN(row[key]) ? row[key] : parseFloat(row[key])
        return {
          ...acc,
          [key]: value,
        }
      }, {})
    })
  // this feels counterintuitive, but we need to sort the data backwards so that it renders in the correct order
  flattenedData.sort((a: FlatData, b: FlatData) => {
    if (dataRender.sortOrder === 'ascending') {
      return ascending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    if (dataRender.sortOrder === 'descending') {
      return descending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    return 0
  })

  flattenedData.reverse()

  // get all unique categories
  const categories = dataRender.categories

  // DATA ACCESSORS

  const getIndependentValue = useCallback(
    (d: FlatData) => d[dataRender.x],
    [dataRender.x],
  )
  const getDependentValue = (d: FlatData) => d.y
  // SCALES
  const independentScale = useMemo(
    () =>
      scalePoint<string>({
        domain: flattenedData.map(getIndependentValue),
        padding: 0.5,
      }),
    [flattenedData, getIndependentValue],
  )
  const dependentScale = useMemo(
    () =>
      scaleLinear({
        // domain: [0, max(flattenedData, getDependentValue) || 0],
        domain: dependentAxis.domain,
        range: [0, innerWidth],
        nice: true,
      }),
    [innerWidth, dependentAxis.domain],
  )
  const colorScale = scaleOrdinal<string, string>({
    domain: categories as string[],
    range: colors,
  })

  dependentScale.rangeRound([0, innerWidth])
  independentScale.rangeRound([innerHeight, 0])

  // GET SHARED LAYOUT PROPS
  const {
    dependentAxisProps,
    independentAxisProps,
    dependentGridProps,
    independentGridProps,
    ariaProps,
    legendProps,
    tooltipVisible,
    labelProps,
  } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A dot plot chart',
        config,
        data: flattenedData,
        size,
        tableData,
        dependentScale,
        independentScale,
      }),
    [config, flattenedData, size, tableData, dependentScale, independentScale],
  )

  // TOOLTIP AND HANDLERS
  const {
    tooltipData,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip<FlatData>()
  let tooltipTimeout: number

  return (
    <div style={{ position: 'relative' }}>
      <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
        <Group top={padding.top} left={padding.left} role='presentation'>
          <GridRows {...independentGridProps} />
          <GridColumns {...dependentGridProps} />
          {independentAxis.active && (
            <AxisLeft
              {...independentAxisProps}
              numTicks={flattenedData.length}
            />
          )}
          {dependentAxis.active && (
            <AxisBottom {...dependentAxisProps} top={innerHeight} />
          )}
          {diffColumn.active && diffColumn.category && (
            <DiffColumn
              diffColumn={diffColumn}
              innerHeight={innerHeight}
              innerWidth={innerWidth}
              flattenedData={flattenedData}
              scale={independentScale}
              dataRender={dataRender}
              labels={labelConfig}
              layout={layout}
            />
          )}
          {dotPlot.connectPoints && (
            <g>
              {flattenedData?.map((d: FlatData, i: number) => {
                const values: number[] = categories.map(
                  (category: string) => d[category],
                )
                const minVal = min(values) as number
                const maxVal = max(values) as number

                // check that minVal and maxVal are not empty, then create connecting line
                if (minVal && maxVal)
                  return (
                    <Line
                      key={md5Hash.default(JSON.stringify(d))}
                      from={{
                        x: dependentScale(minVal),
                        y: independentScale(d[dataRender.x]),
                      }}
                      to={{
                        x: dependentScale(maxVal),
                        y: independentScale(d[dataRender.x]),
                      }}
                      stroke={dotPlot.connectingLine.stroke}
                      strokeWidth={dotPlot.connectingLine.strokeWidth}
                      strokeDasharray={dotPlot.connectingLine.strokeDasharray}
                    />
                  )
              })}
            </g>
          )}
          {categories.map((category: string, i: number) => {
            // it's not guaranteed that all categories have the same number of data points
            // so we need to filter out any data points that don't have a value for the current category
            const filteredData = flattenedData.filter(
              (d: FlatData) => d[category] || d[category] !== '',
            )
            return (
              <g key={md5Hash.default(JSON.stringify(category))}>
                {filteredData?.map((d: FlatData, j: number) => {
                  const customTooltip: string = filteredData[j]['__tooltips']?.[
                    category
                  ]
                    ? filteredData[j]['__tooltips']?.[category]
                    : ''
                  return (
                    <StyledCircle
                      key={`dot-plot-node-${md5Hash.default(
                        JSON.stringify(d),
                      )}`}
                      r={nodes.pointSize}
                      tabIndex={0}
                      cy={independentScale(getIndependentValue(d)) || 0}
                      cx={dependentScale(filteredData[j][category])}
                      stroke={colors[i]}
                      strokeOpacity={
                        tooltipData &&
                        tooltipVisible &&
                        tooltip.deemphasizeSiblings &&
                        tooltipData.category !== category
                          ? tooltip.deemphasizeOpacity
                          : 1
                      }
                      strokeWidth={nodes.pointStrokeWidth}
                      fill={nodes.pointFill === 'inherit' ? colors[i] : 'white'}
                      fillOpacity={
                        tooltipData &&
                        tooltipVisible &&
                        tooltip.deemphasizeSiblings &&
                        tooltipData.category !== category
                          ? tooltip.deemphasizeOpacity
                          : 1
                      }
                      onMouseLeave={() => {
                        tooltipTimeout = window.setTimeout(() => {
                          hideTooltip()
                        }, 300)
                      }}
                      onBlur={() => {
                        tooltipTimeout = window.setTimeout(() => {
                          hideTooltip()
                        }, 300)
                      }}
                      onFocus={() => {
                        if (tooltipTimeout) clearTimeout(tooltipTimeout)

                        showTooltip({
                          tooltipData: {
                            x: d.x,
                            y: d[category],
                            category,
                            tooltip: customTooltip,
                          },
                          tooltipTop: independentScale(getIndependentValue(d)),
                          tooltipLeft: dependentScale(d[category]) || 0,
                        })
                      }}
                      onMouseMove={() => {
                        if (tooltipTimeout) clearTimeout(tooltipTimeout)
                        showTooltip({
                          tooltipData: {
                            x: d.x,
                            y: d[category],
                            category,
                            tooltip: customTooltip,
                          },
                          tooltipTop: independentScale(getIndependentValue(d)),
                          tooltipLeft: dependentScale(d[category]) || 0,
                        })
                      }}
                    />
                  )
                })}
                {labelConfig.active &&
                  filteredData?.map((d: FlatData, j: number) => {
                    const customLabel: string = filteredData[j]['__labels']?.[
                      category
                    ]
                      ? flattenedData[j]['__labels']?.[category]
                      : ''
                    return (
                      <text
                        key={`dot-plot-label-${md5Hash.default(
                          JSON.stringify(d),
                        )}`}
                        {...labelProps}
                        y={(independentScale(getIndependentValue(d)) || 0) - 10}
                        x={dependentScale(filteredData[j][category])}
                        fill={
                          labelConfig.color === 'inherit' ? colors[i] : 'black'
                        }
                      >
                        {customLabel
                          ? customLabel
                          : `${getLabelFormat(
                              d[category],
                              category,
                              labelConfig,
                              null,
                            )}`}
                      </text>
                    )
                  })}
              </g>
            )
          })}
          {tooltipData && tooltipVisible && (
            <g>
              <Circle
                cx={tooltipLeft}
                cy={tooltipTop + 1}
                r={nodes.pointSize + 2}
                fill={'transparent'}
                fillOpacity={0.1}
                stroke='black'
                strokeOpacity={0.1}
                strokeWidth={2}
                pointerEvents='none'
              />
              <Circle
                cx={tooltipLeft}
                cy={tooltipTop}
                r={nodes.pointSize + 1}
                fill={'transparent'}
                stroke='white'
                strokeWidth={2}
                pointerEvents='none'
              />
            </g>
          )}
        </Group>
      </svg>
      {legend.active && (
        <StyledLegend legend={legend} theme={theme}>
          <LegendOrdinal
            {...legendProps}
            scale={colorScale}
            domain={
              legend.categories.length > 0
                ? legend.categories
                : colorScale.domain()
            }
          />
        </StyledLegend>
      )}
      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: getIndependentValue(tooltipData),
                      category: tooltipData.category,
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData.tooltip
                ? tooltipData.tooltip
                : getTooltipFormat(
                    {
                      y: getDependentValue(tooltipData),
                      x: getIndependentValue(tooltipData).toString(),
                      category: tooltipData.category,
                      color: colorScale(tooltipData.category || ''),
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default DotPlot
