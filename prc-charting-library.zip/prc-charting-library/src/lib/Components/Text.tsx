type Text = {
  title?: string
  subtitle?: string
  note?: string
  tag?: string
}

export const Title = (props: Text) => {
  const { title } = props
  if (!title) return <></>
  return (
    <div
      className='cb__title'
      dangerouslySetInnerHTML={{ __html: title ? title : '' }}
    />
  )
}

export const Subtitle = (props: Text) => {
  const { subtitle } = props
  if (!subtitle) return <></>
  return (
    <div
      className='cb__subtitle'
      dangerouslySetInnerHTML={{ __html: subtitle ? subtitle : '' }}
    />
  )
}

export const SourceNote = (props: Text) => {
  const { note } = props
  if (!note) return <></>
  return (
    <div
      className='cb__note'
      dangerouslySetInnerHTML={{ __html: note ? note : '' }}
    />
  )
}

export const Tag = (props: Text) => {
  const { tag } = props
  if (!tag) return <></>
  return (
    <div
      className='cb__tag'
      dangerouslySetInnerHTML={{ __html: tag ? tag : '' }}
    />
  )
}
