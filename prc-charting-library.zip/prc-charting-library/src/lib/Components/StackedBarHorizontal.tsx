import { useCallback, useContext, useMemo, useRef } from 'react'

import { DataContext } from '../Utilities/DataContext'
import { useSize, labelFill, scaleAxisNumTicks } from '../Utilities'
import { StyledLegend, StyledTooltip, DiffColumn } from './index'
import {
  getChartDimensions,
  getLabelFormat,
  getTooltipFormat,
  getTooltipHeaderFormat,
  positionBarLabel,
  getSharedProps,
  getDataWithGroupBreaks,
} from './shared'
import type { FlatData } from '../ts/types/flatData'
import type { Size } from '../ts/types/windowSize'
import type { BaseConfig } from '../ts/types/configTypes'
import type { TableData } from '../ts/types/tableData'

import { BarStackHorizontal } from '@visx/shape'
import { Group } from '@visx/group'
import { GridRows, GridColumns } from '@visx/grid'
import { AxisBottom, AxisLeft } from '@visx/axis'
import { scaleLinear, scaleBand, scaleOrdinal } from '@visx/scale'
import { useTooltip } from '@visx/tooltip'
import { localPoint } from '@visx/event'
import { LegendOrdinal } from '@visx/legend'
import { ascending, descending } from 'd3-array'

const StackedBarHorizontal = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }
  const {
    dependentAxis,
    independentAxis,
    layout,
    colors,
    dataRender,
    tooltip,
    labels,
    legend,
    bar: barConfig,
    diffColumn,
  } = config

  // SIZE AND LAYOUT
  const { height, width, parentClass, padding, theme } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)
  const { chartWidth, innerWidth, innerHeight } = getChartDimensions(
    size,
    layout,
    diffColumn,
  )
  let labelCutoff =
    size.width && size.width >= width
      ? labels.labelCutoff
      : labels.labelCutoffMobile
  let scaledNumTicks = useMemo(
    () => scaleAxisNumTicks(dependentAxis.tickCount || 5, chartWidth, width),
    [dependentAxis.tickCount, chartWidth, width],
  )
  // DATA PROCESSING
  let flattenedData = data
    .reduce((acc: string | any[], curr: any) => {
      return acc.concat(curr)
    }, [])
    .map((row: any) => {
      return Object.keys(row).reduce((acc, key) => {
        const value = isNaN(row[key]) ? row[key] : parseFloat(row[key])
        return {
          ...acc,
          [key]: value,
        }
      }, {})
    })
  // this feels counterintuitive, but we need to sort the data backwards so that it renders in the correct order
  flattenedData
    .sort((a: FlatData, b: FlatData) => {
      if (dataRender.sortOrder === 'ascending') {
        return ascending(a[dataRender.sortKey], b[dataRender.sortKey])
      }
      if (dataRender.sortOrder === 'descending') {
        return descending(a[dataRender.sortKey], b[dataRender.sortKey])
      }
      return 0
    })
    .reverse()

  // check if the chart should have group breaks
  if (barConfig.groupBreaksActive && barConfig.groupBreaks) {
    flattenedData = getDataWithGroupBreaks(flattenedData, barConfig)
  }

  // DATA ACCESSORS
  const getIndependentValue = useCallback(
    (d: FlatData) => d[dataRender.x],
    [dataRender.x],
  )
  const getDependentValue = (d: FlatData) => d[dataRender.y]

  // SCALES, VORONOI, INTERPOLATION

  const independentScale = useMemo(
    () =>
      scaleBand<string>({
        domain: flattenedData.map(getIndependentValue),
        padding: barConfig.barPadding,
      }),
    [flattenedData, getIndependentValue, barConfig.barPadding],
  )
  const dependentScale = useMemo(
    () =>
      scaleLinear({
        domain: dependentAxis.domain,
        range: [0, innerWidth],
        nice: true,
      }),
    [innerWidth, dependentAxis.domain],
  )
  const colorScale = useMemo(
    () =>
      scaleOrdinal<string, string>({
        domain: dataRender.categories,
        range: colors,
      }),
    [dataRender.categories, colors],
  )
  dependentScale.rangeRound([0, innerWidth])
  independentScale.rangeRound([innerHeight, 0])

  // GET SHARED LAYOUT PROPS
  const {
    dependentAxisProps,
    independentAxisProps,
    dependentGridProps,
    independentGridProps,
    ariaProps,
    legendProps,
    tooltipVisible,
    labelProps,
  } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A stacked horizontal bar chart',
        config,
        data: flattenedData,
        size,
        tableData,
        dependentScale,
        independentScale,
      }),
    [config, flattenedData, size, tableData, dependentScale, independentScale],
  )
  // TOOLTIP AND HANDLERS
  const {
    tooltipData,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip<FlatData>()

  let tooltipTimeout: number
  return (
    <div style={{ position: 'relative' }}>
      <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
        <Group top={padding.top} left={padding.left} role='presentation'>
          <GridColumns {...dependentGridProps} />
          <GridRows {...independentGridProps} />
          <BarStackHorizontal
            data={flattenedData}
            keys={dataRender.categories}
            height={innerHeight}
            y={getIndependentValue}
            xScale={dependentScale}
            yScale={independentScale}
            color={colorScale}
          >
            {barStacks => {
              return barStacks.map(barStack => {
                return barStack.bars.map((bar, i) => {
                  const category: string = bar.key
                  const barData: FlatData = bar.bar['data']
                  const barValue: number =
                    barData[category as keyof typeof barData]
                  const customLabel: string = barData['__labels']?.[category]
                    ? barData['__labels']?.[category]
                    : ''
                  const customTooltip: string = barData['__tooltips']?.[
                    category
                  ]
                    ? barData['__tooltips']?.[category]
                    : ''
                  // if the bar is a group break, render a line in the middle of the bar
                  if (barData.groupBreak) {
                    const { groupBreaks } = barConfig
                    const { breakStyles } = groupBreaks
                    if ('empty' === breakStyles.variation) {
                      return
                    } else {
                      return (
                        <>
                          <line
                            className='heart-rate-line'
                            key={`barstack-horizontal-break-${barStack.index}-${bar.index}`}
                            x1={bar.x}
                            x2={innerWidth}
                            y1={bar.y + bar.height / 2}
                            y2={bar.y + bar.height / 2}
                            stroke={groupBreaks.breakStyles.stroke}
                            strokeWidth={groupBreaks.breakStyles.strokeWidth}
                          />
                        </>
                      )
                    }
                  } else {
                    return (
                      <g
                        key={`barstack-horizontal-${barStack.index}-${bar.index}`}
                      >
                        <rect
                          x={bar.x}
                          y={bar.y}
                          width={barValue ? Math.abs(bar.width) : 0}
                          height={bar.height}
                          fill={bar.color}
                          tabIndex={0}
                          stroke={
                            barConfig.hasRectStroke
                              ? barConfig.rectStrokeColor
                              : 'none'
                          }
                          strokeWidth={
                            barConfig.hasRectStroke
                              ? barConfig.rectStrokeWidth
                              : '0'
                          }
                          fillOpacity={
                            tooltipData &&
                            tooltipVisible &&
                            tooltip.deemphasizeSiblings &&
                            (tooltipData?.x !== barData.x ||
                              tooltipData?.y !== barValue ||
                              tooltipData?.category !== category)
                              ? tooltip.deemphasizeOpacity
                              : 1
                          }
                          onBlur={() => {
                            tooltipTimeout = window.setTimeout(() => {
                              hideTooltip()
                            }, 300)
                          }}
                          onFocus={() => {
                            if (tooltipTimeout) clearTimeout(tooltipTimeout)
                            showTooltip({
                              tooltipData: {
                                x: barData.x,
                                y: barValue,
                                category,
                                tooltip: customTooltip,
                              },
                              tooltipTop: bar.y,
                              tooltipLeft: bar.x,
                            })
                          }}
                          onMouseLeave={() => {
                            tooltipTimeout = window.setTimeout(() => {
                              hideTooltip()
                            }, 300)
                          }}
                          onMouseMove={event => {
                            if (tooltipTimeout) clearTimeout(tooltipTimeout)
                            const eventSvgCoords = localPoint(event) || {
                              x: 0,
                              y: 0,
                            }
                            showTooltip({
                              tooltipData: {
                                x: barData.x,
                                y: barValue,
                                category,
                                tooltip: customTooltip,
                              },
                              tooltipTop: eventSvgCoords.y,
                              tooltipLeft: eventSvgCoords.x,
                            })
                          }}
                        />
                        {barValue &&
                          labels.active &&
                          labelCutoff < barValue && (
                            <text
                              key={`barstack-horizontal-label-${barStack.index}-${bar.index}`}
                              {...positionBarLabel(
                                {
                                  x: bar.x,
                                  y: bar.y,
                                  width: bar.width,
                                  height: bar.height,
                                  value: barValue,
                                },
                                labels,
                                labelCutoff,
                                'horizontal',
                                'stacked',
                              )}
                              {...labelProps}
                              fill={labelFill(bar.color)}
                              fillOpacity={
                                tooltipData &&
                                tooltipVisible &&
                                tooltip.deemphasizeSiblings &&
                                (tooltipData?.x !== barData.x ||
                                  tooltipData?.y !== barValue ||
                                  tooltipData?.category !== category)
                                  ? tooltip.deemphasizeOpacity
                                  : 1
                              }
                            >
                              {customLabel
                                ? customLabel
                                : `${getLabelFormat(
                                    barValue,
                                    category,
                                    labels,
                                    null,
                                  )}`}
                            </text>
                          )}
                      </g>
                    )
                  }
                })
              })
            }}
          </BarStackHorizontal>
          {diffColumn.active && diffColumn.category && (
            <DiffColumn
              diffColumn={diffColumn}
              innerHeight={innerHeight}
              innerWidth={innerWidth}
              flattenedData={flattenedData}
              scale={independentScale}
              dataRender={dataRender}
              labels={labels}
              layout={layout}
            />
          )}
          {independentAxis.active && (
            <AxisLeft
              {...independentAxisProps}
              tickValues={independentScale.domain()}
              scale={independentScale}
              numTicks={flattenedData.length}
            />
          )}
          {dependentAxis.active && (
            <AxisBottom
              {...dependentAxisProps}
              top={innerHeight}
              scale={dependentScale}
              numTicks={scaledNumTicks}
            />
          )}
        </Group>
      </svg>
      {legend.active && (
        <StyledLegend legend={legend} theme={theme}>
          <LegendOrdinal
            {...legendProps}
            scale={colorScale}
            domain={
              legend.categories.length > 0
                ? legend.categories
                : colorScale.domain()
            }
          />
        </StyledLegend>
      )}

      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: getIndependentValue(tooltipData),
                      category: tooltipData.category,
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData.tooltip
                ? tooltipData.tooltip
                : getTooltipFormat(
                    {
                      x: getIndependentValue(tooltipData),
                      y: getDependentValue(tooltipData),
                      category: tooltipData.category,
                      color: colorScale(tooltipData.category || ''),
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default StackedBarHorizontal
