import { DiffColumn } from '../../ts/types/diffColumn'
import type { Size } from '../../ts/types/windowSize'
import { Layout } from '../../ts/types/layout'

const getOverflowX = (layout: Layout) => {
  if (layout.overflowX === 'scroll') {
    return 'scroll'
  }
  if (layout.overflowX === 'scroll-fixed-y-axis') {
    return 'scroll'
  }
  return 'hidden'
}

const getChartDimensions = (
  size: Size,
  layout: Layout,
  diffColumn?: DiffColumn,
) => {
  // 0th, lets check to see if the overflowX is set to 'scroll', if so, we need to return the layout width as the chart width
  if (layout.overflowX !== 'responsive') {
    return {
      chartWidth: layout.width,
      innerWidth: layout.width - layout.padding.left - layout.padding.right,
      innerHeight: layout.height - layout.padding.top - layout.padding.bottom,
      overflow: getOverflowX(layout),
    }
  }
  // first, check if a diff column is active.
  // if so, it will impact the inner chart width
  const diffColumnTotalWidth =
    diffColumn && diffColumn.active
      ? diffColumn.style.width + diffColumn.style.marginLeft
      : 0
  // if chart width exists, is not 0, and is less than the layout width, use it
  // otherwise, use the layout width
  return {
    chartWidth:
      size.width && size.width !== 0 && size.width < layout.width
        ? size.width
        : layout.width,
    innerWidth:
      (size.width && size.width !== 0 && size.width < layout.width
        ? size.width
        : layout.width) -
      layout.padding.left -
      layout.padding.right -
      diffColumnTotalWidth,
    innerHeight: layout.height - layout.padding.top - layout.padding.bottom,
  }
}

export { getChartDimensions }
