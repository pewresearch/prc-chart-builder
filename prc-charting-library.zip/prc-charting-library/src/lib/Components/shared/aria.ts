import type { FlatData } from '../../ts/types/flatData'
import { TableData } from '../../ts/types/tableData'

type AriaProps = {
  chartType: string
  data: FlatData
  tableData?: TableData
}

export const getAria = (props: AriaProps) => {
  const { chartType, data, tableData } = props
  // first, let's check if this chart has contextual data from a table
  // the data variable has already had some data processing applied to it,
  // which strips out non-numeric values
  // for aria, we should return the original data
  if (!tableData) {
    const keys = Object.keys(data[0]).join(', ')
    // for each object in the data array, get the values and join them with a comma, wrap in brackets
    const values = data
      .map((d: FlatData) => `[${Object.values(d).join(', ')}]`)
      .join(', ')
    return {
      'aria-label': `${chartType}`,
      'aria-datavariables': keys,
      'aria-datavaluearray': values,
    }
  }
  // if we have table data, we should return the original data
  const keys = tableData.header.join(', ')
  const values = tableData.rows
    .map((row: string[]) => `[${row.join(', ')}]`)
    .join(', ')
  return {
    'aria-label': `${chartType}`,
    'aria-datavariables': keys,
    'aria-datavaluearray': values,
  }
}
