import { abbreviateNumber, checkContrast } from '../../Utilities/helpers'
import { timeFormat } from 'd3-time-format'
import { independentAxis, dependentAxis } from '../../ts/types/configTypes'
import { AxisScale, AxisScaleOutput } from '@visx/axis'
const formatTicks = (
  config: independentAxis | dependentAxis,
  t: number | Date | string,
) => {
  if (
    config.customTickFormat &&
    typeof config.customTickFormat === 'function'
  ) {
    return config.customTickFormat(t)
  }

  if (config.scale === 'time') {
    config = config as independentAxis
    t = t as Date
    const d3DateFormat = timeFormat(config.dateFormat)
    if (config.tickUnit) {
      if (config.tickUnitPosition === 'end') {
        return `${d3DateFormat(t)}${config.tickUnit}`
      }
      return `${config.tickUnit}${d3DateFormat(t)}`
    }
    return d3DateFormat(t)
  }
  t = t as number
  if (config.abbreviateTicks) {
    if (config.tickUnit) {
      if (config.tickUnitPosition === 'end') {
        return `${abbreviateNumber(t, config.abbreviateTicksDecimals)}${
          config.tickUnit
        }`
      }
      return `${config.tickUnit}${abbreviateNumber(
        t,
        config.abbreviateTicksDecimals,
      )}`
    }
    return abbreviateNumber(t, config.abbreviateTicksDecimals)
  }
  if (config.ticksToLocaleString) {
    if (config.tickUnit) {
      if (config.tickUnitPosition === 'end') {
        return `${t.toLocaleString()}${config.tickUnit}`
      }
      return `${config.tickUnit}${t.toLocaleString()}`
    }
    return t.toLocaleString()
  }
  if (config.tickUnit) {
    if (config.tickUnitPosition === 'end') {
      return `${t}${config.tickUnit}`
    }
    return `${config.tickUnit}${t}`
  }
  return `${t}`
}

const getColor = (color: string, theme: string) => {
  if (theme === 'light') {
    return color
  }
  return checkContrast(color, '#1e1e1e') > 3 ? color : '#ccc'
}

const getAxisProps = (
  config: independentAxis | dependentAxis,
  scale: AxisScale<AxisScaleOutput>,
  theme: 'light' | 'dark',
) => {
  const { axis, ticks, axisLabel, tickLabels } = config
  return {
    scale: scale,
    hideAxisLine: !config.active,
    hideTicks: !config.active,
    stroke: getColor(axis.stroke, theme),
    strokeWidth: axis.strokeWidth,
    tickStroke: getColor(axis.stroke, theme),
    tickLength: ticks.size,
    hideZero: !config.showZero,
    label: config.label ? config.label : '',
    labelOffset: axisLabel.padding,
    numTicks: config.tickCount,
    tickValues:
      config.scale === 'time'
        ? (config as independentAxis).tickValues?.map(t => {
            var date = new Date(t)
            date.setDate(date.getDate() + 1)
            return date
          })
        : (config.tickValues as number[]),
    labelProps: {
      fill: getColor(axisLabel.fill, theme),
      fontSize: axisLabel.fontSize,
      textAnchor: axisLabel.textAnchor,
      dy: axisLabel.dy,
      dx: axisLabel.dx,
      fontFamily: axisLabel.fontFamily,
      verticalAnchor: axisLabel.verticalAnchor,
      angle: axisLabel.angle,
      width: axisLabel.maxWidth,
    },
    tickFormat: (t: any) => formatTicks(config, t),
    tickLabelProps: () => {
      return {
        fill: getColor(tickLabels.fill, theme),
        fontSize: tickLabels.fontSize,
        textAnchor: tickLabels.textAnchor,
        dy: tickLabels.dy,
        dx: tickLabels.dx,
        fontFamily: tickLabels.fontFamily,
        verticalAnchor: tickLabels.verticalAnchor,
        angle: tickLabels.angle,
        width: tickLabels.maxWidth,
      }
    },
  }
}

export { getAxisProps }
