import { Bar } from '../../ts/types/bar'
import { FlatData } from '../../ts/types/flatData'

const getDataWithGroupBreaks = (data: FlatData, bar: Bar) => {
  const { groupBreaksActive, groupBreaks } = bar
  if (!groupBreaksActive || !groupBreaks) {
    return data
  }
  groupBreaks.values.forEach((value, i) => {
    // Find the index of the object in data where x matches the year
    const index = data.findIndex(
      (d: { x: string | number }) =>
        d.x === value || d.x === value.toString() || Number(d.x) === value,
    )
    // Create a new object with the break styles
    const newObject = {
      x: groupBreaks.labelsActive ? groupBreaks.labels[i] : '',
      groupBreak: true,
    }
    // If a matching object is found, prepend the new object
    if (index !== -1) {
      data.splice(index, 0, newObject)
    }
  })
  return data
}

export { getDataWithGroupBreaks }
