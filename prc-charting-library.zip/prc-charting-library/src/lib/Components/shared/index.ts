// shared hooks
import { getAria } from './aria'
import { getAxisProps } from './axes'
import { getGridProps } from './grid'
import { getLabelFormat, getLabelProps, positionBarLabel } from './labels'
import { getLegendProps } from './legend'
import { getLineProps } from './line'
import { getChartDimensions } from './size'
import {
  getTooltipFormat,
  getTooltipHeaderFormat,
  getTooltipVisible,
} from './tooltips'
import { getVoronoiProps } from './voronoi'
import { getDataWithGroupBreaks } from './groupBreaks'
import type { FlatData } from '../../ts/types/flatData'
import type { TableData } from '../../ts/types/tableData'
import type { BaseConfig } from '../../ts/types/configTypes'
import type { Size } from '../../ts/types/windowSize'

type SharedProps = {
  config: BaseConfig
  data: FlatData | any
  size: Size
  tableData?: TableData
  chartType: string
  dependentScale?: any
  independentScale?: any
}

const getSharedProps = ({
  config,
  data,
  size,
  tableData,
  chartType,
  dependentScale,
  independentScale,
}: SharedProps) => {
  const {
    dependentAxis,
    independentAxis,
    layout,
    tooltip,
    labels,
    legend,
    diffColumn,
    voronoi,
  } = config
  const { chartWidth, innerWidth, innerHeight } = getChartDimensions(
    size,
    layout,
    diffColumn,
  )

  return {
    ariaProps: getAria({ chartType: chartType, data, tableData }),
    labelProps: getLabelProps(labels),
    legendProps: getLegendProps(legend),
    voronoiProps: getVoronoiProps(voronoi),
    dependentAxisProps: getAxisProps(
      dependentAxis,
      dependentScale,
      layout.theme,
    ),
    independentAxisProps: getAxisProps(
      independentAxis,
      independentScale,
      layout.theme,
    ),
    dependentGridProps: getGridProps(
      dependentAxis,
      dependentScale,
      innerWidth,
      innerHeight,
    ),
    independentGridProps: getGridProps(
      independentAxis,
      independentScale,
      innerWidth,
      innerHeight,
    ),
    tooltipVisible: getTooltipVisible(layout, chartWidth, tooltip),
    chartWidth,
    innerWidth,
    innerHeight,
  }
}

export {
  getSharedProps,
  getAria,
  getAxisProps,
  getGridProps,
  getLabelFormat,
  getLabelProps,
  positionBarLabel,
  getLegendProps,
  getLineProps,
  getChartDimensions,
  getTooltipFormat,
  getTooltipHeaderFormat,
  getTooltipVisible,
  getVoronoiProps,
  getDataWithGroupBreaks,
}
