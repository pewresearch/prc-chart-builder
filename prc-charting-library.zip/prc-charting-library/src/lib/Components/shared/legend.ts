import { Legend } from '../../ts/types/legend'

export const getLegendProps = (config: Legend) => {
  const { orientation, markerStyle } = config
  return {
    style: {
      display: 'flex',
      flexFlow: `${orientation} wrap`,
    },
    shape: markerStyle,
    shapeWidth: 12,
    shapeHeight: 12,
    direction: orientation,
    labelMargin: '0 15px 0 0',
  }
}
