const getScatterProps = () => {
  return {};
};

export { getScatterProps };
