import { useContext, useMemo, useCallback, useRef } from 'react'

import { DataContext } from '../Utilities/DataContext'
import { useSize, labelFill } from '../Utilities'
import {
  getChartDimensions,
  getLabelFormat,
  positionBarLabel,
  getTooltipFormat,
  getTooltipHeaderFormat,
  getSharedProps,
} from './shared'
import type { FlatData } from '../ts/types/flatData'
import type { Size } from '../ts/types/windowSize'
import type { BaseConfig } from '../ts/types/configTypes'
import type { TableData } from '../ts/types/tableData'
import { StyledTooltip, StyledLegend, DiffColumn } from './index'

import { Line as VerticalLine, BarStackHorizontal } from '@visx/shape'
import { Group } from '@visx/group'
import { GridRows, GridColumns } from '@visx/grid'
import { AxisBottom, AxisLeft } from '@visx/axis'
import { scaleLinear, scaleBand, scaleOrdinal } from '@visx/scale'
import { useTooltip } from '@visx/tooltip'
import { localPoint } from '@visx/event'
import { ascending, descending } from 'd3-array'
import { LegendOrdinal } from '@visx/legend'

const DivergingBarHorizontal = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }
  const {
    dependentAxis,
    independentAxis,
    layout,
    colors,
    dataRender,
    tooltip,
    labels,
    legend,
    divergingBar,
    bar: barConfig,
    diffColumn,
  } = config as BaseConfig

  // LAYOUT
  const { width, height, parentClass, padding, theme } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)
  const { chartWidth, innerWidth, innerHeight } = getChartDimensions(
    size,
    layout,
    diffColumn,
  )
  let labelCutoff =
    size.width && size.width >= width
      ? labels.labelCutoff
      : labels.labelCutoffMobile
  // DATA PROCESSING
  // this data is a little different than the others. Because the data stack's offset is divergent,
  // we need to convert the keys that belong to the negative categories to negative values
  const flattenedData = data
    .reduce((acc: string | any[], curr: any) => {
      return acc.concat(curr)
    }, [])
    .map((row: any) => {
      return Object.keys(row).reduce((acc, key) => {
        const value = isNaN(row[key]) ? row[key] : parseFloat(row[key])
        const isNegative = divergingBar.negativeCategories.includes(key)
        return {
          ...acc,
          [key]: isNegative ? -value : value,
        }
      }, {})
    })

  flattenedData.sort((a: FlatData, b: FlatData) => {
    if (dataRender.sortOrder === 'ascending') {
      return ascending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    if (dataRender.sortOrder === 'descending') {
      return descending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    return 0
  })
  // this feels counterintuitive,
  // but we need to reverse the data because
  // d3 stacks the data from the bottom up.
  // UNLESS the sortKey is a negative category,
  // then we can just leave it as is.
  // Sorry.
  if (!divergingBar.negativeCategories.includes(dataRender.sortKey)) {
    flattenedData.reverse()
  }

  // DATA ACCESSORS
  const getIndependentValue = useCallback(
    (d: FlatData) => d[dataRender.x],
    [dataRender.x],
  )

  // const getDependentValue = (d: FlatData) => d.y;
  // SCALES, VORONOI, INTERPOLATION

  const independentScale = useMemo(
    () =>
      scaleBand<string>({
        domain: flattenedData.map(getIndependentValue),
        padding: barConfig.barPadding,
      }),
    [flattenedData, getIndependentValue, barConfig],
  )
  const dependentScale = useMemo(
    () =>
      scaleLinear({
        domain: dependentAxis.domain,
        range: [0, innerWidth],
        nice: true,
      }),
    [innerWidth, dependentAxis.domain],
  )

  const colorScale = useMemo(
    () =>
      scaleOrdinal<string, string>({
        domain: [
          ...divergingBar.negativeCategories,
          ...divergingBar.positiveCategories,
        ],
        range: colors,
      }),
    [divergingBar, colors],
  )

  // tweak the ranges of scales if the neutral bar is active
  if (divergingBar.neutralBar.active) {
    dependentScale.rangeRound([
      0,
      innerWidth * divergingBar.percentOfInnerWidth,
    ])
    colorScale.domain([
      ...divergingBar.negativeCategories,
      ...divergingBar.positiveCategories,
      divergingBar.neutralBar.category,
    ])
  } else {
    dependentScale.rangeRound([0, innerWidth])
  }
  independentScale.rangeRound([innerHeight, 0])

  // GET SHARED LAYOUT PROPS
  const {
    dependentAxisProps,
    independentAxisProps,
    dependentGridProps,
    independentGridProps,
    ariaProps,
    legendProps,
    tooltipVisible,
    labelProps,
  } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A diverging horizontal bar chart',
        config,
        data: flattenedData,
        size,
        tableData,
        dependentScale,
        independentScale,
      }),
    [config, flattenedData, size, tableData, dependentScale, independentScale],
  )

  // TOOLTIP AND HANDLERS
  const {
    tooltipData,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip<FlatData>()

  let tooltipTimeout: number

  return (
    <div style={{ position: 'relative' }}>
      <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
        <Group top={padding.top} left={padding.left} role='presentation'>
          <GridRows {...independentGridProps} />
          <GridColumns {...dependentGridProps} />
          {independentAxis.active && (
            <AxisLeft
              {...independentAxisProps}
              tickValues={independentScale.domain()}
              scale={independentScale}
              numTicks={flattenedData.length}
            />
          )}
          {dependentAxis.active && (
            <AxisBottom
              {...dependentAxisProps}
              top={innerHeight}
              scale={dependentScale}
            />
          )}
          <BarStackHorizontal
            data={flattenedData}
            keys={[
              ...divergingBar.negativeCategories,
              ...divergingBar.positiveCategories,
            ]}
            height={innerHeight}
            y={getIndependentValue}
            xScale={dependentScale}
            yScale={independentScale}
            color={colorScale}
            offset={'diverging'}
            width={innerWidth * divergingBar.percentOfInnerWidth}
          >
            {barStacks => {
              return barStacks.map(barStack =>
                barStack.bars.map((bar, i) => {
                  const category: string = bar.key
                  const barData = bar.bar['data']
                  const barValue: number =
                    barData[category as keyof typeof barData]
                  const customLabel: string = barData['__labels']?.[category]
                    ? barData['__labels']?.[category]
                    : ''
                  const customTooltip: string = barData['__tooltips']?.[
                    category
                  ]
                    ? barData['__tooltips']?.[category]
                    : ''
                  return (
                    <g
                      key={`barstack-horizontal-${barStack.index}-${bar.index}-g`}
                    >
                      <rect
                        key={`barstack-horizontal-${barStack.index}-${bar.index}`}
                        x={bar.x}
                        y={bar.y}
                        tabIndex={0}
                        width={barValue ? Math.abs(bar.width) : 0}
                        height={bar.height}
                        fill={bar.color}
                        stroke={
                          barConfig.hasRectStroke
                            ? barConfig.rectStrokeColor
                            : 'none'
                        }
                        strokeWidth={
                          barConfig.hasRectStroke
                            ? barConfig.rectStrokeWidth
                            : '0'
                        }
                        fillOpacity={
                          tooltipData &&
                          tooltipVisible &&
                          tooltip.deemphasizeSiblings &&
                          (tooltipData?.x !== barData.x ||
                            tooltipData?.y !== barValue ||
                            tooltipData?.category !== category)
                            ? tooltip.deemphasizeOpacity
                            : 1
                        }
                        onMouseLeave={() => {
                          tooltipTimeout = window.setTimeout(() => {
                            hideTooltip()
                          }, 300)
                        }}
                        onMouseMove={event => {
                          if (tooltipTimeout) clearTimeout(tooltipTimeout)
                          const eventSvgCoords = localPoint(event) || {
                            x: 0,
                            y: 0,
                          }

                          showTooltip({
                            tooltipData: {
                              x: barData.x,
                              y: barValue,
                              category,
                              tooltip: customTooltip,
                            },
                            tooltipTop: eventSvgCoords.y,
                            tooltipLeft: eventSvgCoords.x,
                          })
                        }}
                        onBlur={() => {
                          tooltipTimeout = window.setTimeout(() => {
                            hideTooltip()
                          }, 300)
                        }}
                        onFocus={() => {
                          if (tooltipTimeout) clearTimeout(tooltipTimeout)
                          showTooltip({
                            tooltipData: {
                              x: barData.x,
                              y: barValue,
                              category,
                              tooltip: customTooltip,
                            },
                            tooltipTop: bar.y,
                            tooltipLeft: bar.x,
                          })
                        }}
                      />
                      {barValue &&
                        labels.active &&
                        labelCutoff < Math.abs(barValue) && (
                          <text
                            key={`barstack-horizontal-label-${barStack.index}-${bar.index}`}
                            {...labelProps}
                            {...positionBarLabel(
                              {
                                x: bar.x,
                                y: bar.y,
                                width: bar.width,
                                height: bar.height,
                                value: barValue,
                              },
                              labels,
                              labelCutoff,
                              'horizontal',
                              'stacked',
                            )}
                            fill={labelFill(bar.color)}
                            fillOpacity={
                              tooltipData &&
                              tooltipVisible &&
                              tooltip.deemphasizeSiblings &&
                              (tooltipData?.x !== barData.x ||
                                tooltipData?.y !== barValue ||
                                tooltipData?.category !== category)
                                ? tooltip.deemphasizeOpacity
                                : 1
                            }
                          >
                            {customLabel
                              ? customLabel
                              : `${getLabelFormat(
                                  barValue,
                                  category,
                                  labels,
                                  labelCutoff,
                                )}`}
                          </text>
                        )}
                    </g>
                  )
                }),
              )
            }}
          </BarStackHorizontal>
          <VerticalLine
            from={{ x: dependentScale(0), y: 0 }}
            to={{ x: dependentScale(0), y: innerHeight + 0 }}
            stroke={dependentAxis.axis.stroke}
            strokeWidth={dependentAxis.axis.strokeWidth}
            pointerEvents='none'
          />
          {diffColumn.active && diffColumn.category && (
            <DiffColumn
              diffColumn={diffColumn}
              innerHeight={innerHeight}
              innerWidth={innerWidth}
              flattenedData={flattenedData}
              scale={independentScale}
              dataRender={dataRender}
              labels={labels}
              layout={layout}
            />
          )}
        </Group>
        {divergingBar.neutralBar.active && !diffColumn.active && (
          <Group
            top={padding.top}
            left={
              innerWidth * divergingBar.percentOfInnerWidth +
              divergingBar.neutralBar.offsetX
            }
            role='presentation'
          >
            {dependentAxis.active && (
              <AxisBottom
                top={innerHeight}
                {...dependentAxisProps}
                scale={dependentScale}
              />
            )}
            <BarStackHorizontal
              data={flattenedData}
              keys={[divergingBar.neutralBar.category]}
              height={innerHeight}
              y={getIndependentValue}
              xScale={dependentScale}
              yScale={independentScale}
              color={colorScale}
            >
              {barStacks => {
                return barStacks.map(barStack =>
                  barStack.bars.map((bar, i) => {
                    const category: string = bar.key
                    const barData: FlatData = bar.bar['data']
                    const barValue: number =
                      barData[category as keyof typeof barData]
                    const customLabel: string = barData['__labels']?.[category]
                      ? barData['__labels']?.[category]
                      : ''
                    const customTooltip: string = barData['__tooltips']?.[
                      category
                    ]
                      ? barData['__tooltips']?.[category]
                      : ''

                    return (
                      <g
                        key={`barstack-horizontal-neutral-${barStack.index}-${bar.index}-g`}
                      >
                        <rect
                          key={`barstack-horizontal-neutral-${barStack.index}-${bar.index}`}
                          x={bar.x}
                          y={bar.y}
                          tabIndex={0}
                          width={barValue ? Math.abs(bar.width) : 0}
                          height={bar.height}
                          fill={bar.color}
                          stroke={
                            barConfig.hasRectStroke
                              ? barConfig.rectStrokeColor
                              : 'none'
                          }
                          strokeWidth={
                            barConfig.hasRectStroke
                              ? barConfig.rectStrokeWidth
                              : '0'
                          }
                          fillOpacity={
                            tooltipData &&
                            tooltipVisible &&
                            tooltip.deemphasizeSiblings &&
                            (tooltipData?.x !== barData.x ||
                              tooltipData?.y !== barValue ||
                              tooltipData?.category !== category)
                              ? tooltip.deemphasizeOpacity
                              : 1
                          }
                          onMouseLeave={() => {
                            tooltipTimeout = window.setTimeout(() => {
                              hideTooltip()
                            }, 300)
                          }}
                          onMouseMove={event => {
                            if (tooltipTimeout) clearTimeout(tooltipTimeout)
                            const eventSvgCoords = localPoint(event) || {
                              x: 0,
                              y: 0,
                            }

                            showTooltip({
                              tooltipData: {
                                x: barData.x,
                                y: barValue,
                                category,
                                tooltip: customTooltip,
                              },
                              tooltipTop: eventSvgCoords.y,
                              tooltipLeft: eventSvgCoords.x,
                            })
                          }}
                        />
                        {barValue && labels.active && (
                          <text
                            key={`barstack-horizontal-neutral-label-${barStack.index}-${bar.index}`}
                            {...labelProps}
                            {...positionBarLabel(
                              {
                                x: bar.x,
                                y: bar.y,
                                width: bar.width,
                                height: bar.height,
                                value: barValue,
                              },
                              labels,
                              labelCutoff,
                              'horizontal',
                              'single',
                            )}
                            fill={
                              labels.labelPositionBar === 'outside' ||
                              barValue < labelCutoff
                                ? theme === 'light'
                                  ? 'black'
                                  : 'white'
                                : labelFill(bar.color)
                            }
                            fillOpacity={
                              tooltipData &&
                              (tooltipData?.x !== barData.x ||
                                tooltipData?.y !== barValue ||
                                tooltipData?.category !== category)
                                ? tooltip.deemphasizeOpacity
                                : 1
                            }
                          >
                            {customLabel
                              ? customLabel
                              : `${getLabelFormat(
                                  barValue,
                                  category,
                                  labels,
                                  null,
                                )}`}
                          </text>
                        )}
                      </g>
                    )
                  }),
                )
              }}
            </BarStackHorizontal>
            {divergingBar.neutralBar.separator && (
              <VerticalLine
                from={{
                  x: dependentScale(divergingBar.neutralBar.separatorOffsetX),
                  y: 0,
                }}
                to={{
                  x: dependentScale(divergingBar.neutralBar.separatorOffsetX),
                  y: innerHeight + 0,
                }}
                stroke={'#ccc'}
                strokeWidth={dependentAxis.axis.strokeWidth}
                strokeDasharray={'2 2'}
                pointerEvents='none'
              />
            )}
          </Group>
        )}
      </svg>
      {legend.active && (
        <StyledLegend legend={legend} theme={theme}>
          <LegendOrdinal
            {...legendProps}
            scale={colorScale}
            domain={
              legend.categories.length > 0
                ? legend.categories
                : colorScale.domain()
            }
          />
        </StyledLegend>
      )}
      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: tooltipData.x,
                      category: tooltipData.category,
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData.tooltip
                ? tooltipData.tooltip
                : getTooltipFormat(
                    {
                      x: tooltipData.x,
                      y: tooltipData.y,
                      category: tooltipData.category,
                      color: colorScale(tooltipData.category || ''),
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default DivergingBarHorizontal
