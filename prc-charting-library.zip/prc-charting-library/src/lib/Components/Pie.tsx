import { useContext, useMemo, useRef } from 'react'

import { DataContext } from '../Utilities/DataContext'
import { labelFill, useSize } from '../Utilities'
import {
  getLabelFormat,
  getChartDimensions,
  getTooltipFormat,
  getTooltipHeaderFormat,
  getSharedProps,
} from './shared'
import { StyledTooltip, StyledLegend } from './index'
import type { FlatData } from '../ts/types/flatData'
import type { Size } from '../ts/types/windowSize'
import type { BaseConfig } from '../ts/types/configTypes'
import type { TableData } from '../ts/types/tableData'

import { Pie as VisxPie } from '@visx/shape'
import { Group } from '@visx/group'
import { LegendOrdinal } from '@visx/legend'
import { useTooltip } from '@visx/tooltip'
import { localPoint } from '@visx/event'
import { ascending, descending } from 'd3-array'
import { scaleOrdinal } from '@visx/scale'

const Pie = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }
  const {
    layout,
    labels,
    colors,
    tooltip,
    legend,
    dataRender,
    pie: pieConfig,
  } = config

  // LAYOUT
  const { height, parentClass, padding, theme } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)
  const { chartWidth, innerWidth, innerHeight } = getChartDimensions(
    size,
    layout,
  )
  const radius = Math.min(innerWidth, innerHeight) / 2
  const centerY = innerHeight / 2
  const centerX = innerWidth / 2
  const top = centerY + padding.top
  const left = centerX + padding.left

  // DATA PROCESSING
  const flattenedData = data.reduce((acc: string | any[], curr: any) => {
    return acc.concat(curr)
  }, [])
  flattenedData.sort((a: FlatData, b: FlatData) => {
    if (dataRender.sortOrder === 'ascending') {
      return ascending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    if (dataRender.sortOrder === 'descending') {
      return descending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    return 0
  })
  const pieSortValues = (a: number, b: any) => {
    if (dataRender.sortOrder === 'ascending') {
      return a - b
    }
    if (dataRender.sortOrder === 'descending') {
      return b - a
    }
    return 0
  }

  // ACCESSORS
  const getIndependentValue = (d: any) => d.x
  const getDependentValue = (d: any) => d[dataRender.categories[0]]

  // SCALES
  const colorScale = useMemo(
    () =>
      scaleOrdinal<string, string>({
        domain: flattenedData.map(getIndependentValue),
        range: colors,
      }),
    [flattenedData, colors],
  )
  // GET SHARED LAYOUT PROPS
  const { ariaProps, legendProps, tooltipVisible, labelProps } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A pie chart',
        config,
        data: flattenedData,
        size,
        tableData,
      }),
    [config, flattenedData, size, tableData],
  )
  // TOOLTIP
  const {
    tooltipOpen,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipData,
    hideTooltip,
    showTooltip,
  } = useTooltip<FlatData>()
  let tooltipTimeout: number

  return (
    <div style={{ position: 'relative' }}>
      <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
        <Group top={top} left={left} role='presentation'>
          <VisxPie
            data={flattenedData}
            pieValue={getDependentValue}
            pieSortValues={pieSortValues}
            outerRadius={radius}
          >
            {pie => {
              return pie.arcs.map((arc, index) => {
                const { x } = arc.data
                const depVal = getDependentValue(arc.data)
                const customLabel: string = arc.data['__labels']?.[
                  dataRender.categories[0]
                ]
                  ? arc.data['__labels']?.[dataRender.categories[0]]
                  : ''

                const [centroidX, centroidY] = pie.path.centroid(arc)
                const hasSpaceForLabel = arc.endAngle - arc.startAngle >= 0.1
                const arcPath = pie.path(arc) || ''
                return (
                  <g key={`arc-${x}-${index}`}>
                    <path
                      d={arcPath}
                      fill={colors[index]}
                      stroke={
                        pieConfig.hasPathStroke ? pieConfig.pathStrokeColor : ''
                      }
                      strokeWidth={
                        pieConfig.hasPathStroke ? pieConfig.pathStrokeWidth : 0
                      }
                      fillOpacity={
                        tooltipData &&
                        tooltipVisible &&
                        tooltip.deemphasizeSiblings &&
                        arc.data !== tooltipData
                          ? tooltip.deemphasizeOpacity
                          : 1
                      }
                      onBlur={() => {
                        tooltipTimeout = window.setTimeout(() => {
                          hideTooltip()
                        }, 300)
                      }}
                      onFocus={event => {
                        if (tooltipTimeout) clearTimeout(tooltipTimeout)
                        const data = { ...arc.data, color: colors[index] }
                        showTooltip({
                          tooltipData: data,
                          tooltipTop: centroidY,
                          tooltipLeft: centroidX,
                        })
                      }}
                      onMouseLeave={() => {
                        tooltipTimeout = window.setTimeout(() => {
                          hideTooltip()
                        }, 300)
                      }}
                      onMouseMove={event => {
                        if (tooltipTimeout) clearTimeout(tooltipTimeout)
                        const eventSvgCoords = localPoint(event)
                        const data = { ...arc.data, color: colors[index] }
                        showTooltip({
                          tooltipData: data,
                          tooltipTop: eventSvgCoords!.y,
                          tooltipLeft: eventSvgCoords!.x,
                        })
                      }}
                    />
                    {hasSpaceForLabel && (
                      <text
                        {...labelProps}
                        x={centroidX}
                        y={centroidY}
                        dy='.33em'
                        fill={labelFill(colors[index])}
                        fillOpacity={
                          tooltipData &&
                          tooltipVisible &&
                          tooltip.deemphasizeSiblings &&
                          arc.data !== tooltipData
                            ? tooltip.deemphasizeOpacity
                            : 1
                        }
                      >
                        {customLabel
                          ? customLabel
                          : `${getLabelFormat(depVal, x, labels, null)}`}
                      </text>
                    )}
                  </g>
                )
              })
            }}
          </VisxPie>
          {pieConfig.showCategoryLabels && (
            <VisxPie
              data={flattenedData}
              pieValue={getDependentValue}
              pieSortValues={pieSortValues}
              innerRadius={radius + 20}
              outerRadius={radius + 40}
            >
              {pie => {
                return pie.arcs.map((arc, index) => {
                  const { x } = arc.data
                  const indepVal = getIndependentValue(arc.data)

                  const [centroidX, centroidY] = pie.path.centroid(arc)
                  const hasSpaceForLabel = arc.endAngle - arc.startAngle >= 0.1
                  const arcPath = pie.path(arc) || ''
                  return (
                    <g key={`arc-${x}-${index}`}>
                      <path
                        d={arcPath}
                        fill={'transparent'}
                        fillOpacity={
                          tooltipData &&
                          tooltipVisible &&
                          tooltip.deemphasizeSiblings &&
                          arc.data !== tooltipData
                            ? tooltip.deemphasizeOpacity
                            : 1
                        }
                        onMouseLeave={() => {
                          tooltipTimeout = window.setTimeout(() => {
                            hideTooltip()
                          }, 300)
                        }}
                        onMouseMove={event => {
                          if (tooltipTimeout) clearTimeout(tooltipTimeout)
                          const eventSvgCoords = localPoint(event)
                          showTooltip({
                            tooltipData: arc.data,
                            tooltipTop: eventSvgCoords!.y,
                            tooltipLeft: eventSvgCoords!.x,
                          })
                        }}
                      />
                      {hasSpaceForLabel && (
                        <text
                          {...labelProps}
                          x={centroidX}
                          y={centroidY}
                          dy='.33em'
                          fill={'#000'}
                          fillOpacity={
                            tooltipData &&
                            tooltipVisible &&
                            tooltip.deemphasizeSiblings &&
                            arc.data !== tooltipData
                              ? tooltip.deemphasizeOpacity
                              : 1
                          }
                        >
                          {indepVal}
                        </text>
                      )}
                      // create a line from the text element to the inner radius
                      of the arc
                      {/* <line
                      x1={centroidX}
                      y1={centroidY}
                      x2={centroidX}
                      y2={centroidY + 10}
                      stroke={'#000'}
                      strokeWidth={1}
                      strokeOpacity={0.5}
                      strokeLinecap={'round'}
                    /> */}
                    </g>
                  )
                })
              }}
            </VisxPie>
          )}
        </Group>
      </svg>
      {legend.active && (
        <StyledLegend legend={legend} theme={theme}>
          <LegendOrdinal
            {...legendProps}
            scale={colorScale}
            domain={
              legend.categories.length > 0
                ? legend.categories
                : colorScale.domain()
            }
          />
        </StyledLegend>
      )}
      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: getIndependentValue(tooltipData),
                      category: dataRender.categories[0],
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>

          <div>{}</div>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData['__tooltips']?.[dataRender.categories[0]]
                ? tooltipData['__tooltips']?.[dataRender.categories[0]]
                : getTooltipFormat(
                    {
                      x: getIndependentValue(tooltipData),
                      y: getDependentValue(tooltipData),
                      category: dataRender.categories[0],
                      color: tooltipData.color,
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default Pie
