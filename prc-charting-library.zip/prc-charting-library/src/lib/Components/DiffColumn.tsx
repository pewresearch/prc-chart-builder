import { Text } from '@visx/text'
import {
  DiffColumn as DiffColumnType,
  DataRender,
  Labels,
  Layout,
} from '../ts/types/configTypes'
import type { FlatData } from '../ts/types/flatData'

type DiffColumnProps = {
  diffColumn: DiffColumnType
  layout: Layout
  dataRender: DataRender
  flattenedData: FlatData[]
  labels: Labels
  innerHeight: number
  innerWidth: number
  scale: any
}

export const DiffColumn = ({
  diffColumn,
  innerHeight,
  innerWidth,
  flattenedData,
  scale,
  dataRender,
  labels,
  layout,
}: DiffColumnProps) => {
  return (
    <g
      x={innerWidth + diffColumn.style.marginLeft}
      y={0}
      width={diffColumn.style.width}
      height={innerHeight}
    >
      <rect
        x={innerWidth + diffColumn.style.marginLeft}
        y={-diffColumn.style.heightOffset}
        width={diffColumn.style.width}
        height={innerHeight + diffColumn.style.heightOffset}
        fill={diffColumn.style.rectFill || '#fff'}
      />
      <Text
        width={diffColumn.style.width}
        x={
          innerWidth + diffColumn.style.marginLeft + diffColumn.style.width / 2
        }
        y={0}
        textAnchor='middle'
        style={{
          fontSize: diffColumn.style.headerFontSize,
          fontWeight: diffColumn.style.fontWeight,
          fontStyle: diffColumn.style.fontStyle,
        }}
      >
        {diffColumn.columnHeader}
      </Text>
      {flattenedData?.map((d: FlatData, i: number) => {
        const { dx, dy, style, category } = diffColumn
        const y =
          layout.type === 'dot-plot'
            ? scale(d[dataRender.x])
            : // TODO: fix this magic number
              (scale(d[dataRender.x]) ?? 0) + labels.labelPositionDY + 12
        return (
          <text
            style={{
              fontSize: labels.fontSize,
              fontWeight: style.fontWeight,
              fontStyle: style.fontStyle,
            }}
            width={style.width}
            x={innerWidth + diffColumn.style.marginLeft + style.width / 2}
            y={y}
            dx={dx}
            dy={dy}
            dominant-baseline='middle'
            text-anchor='middle'
          >
            {d[category]}
          </text>
        )
      })}
    </g>
  )
}
