import { TooltipWithBounds } from '@visx/tooltip'
import { Tooltip as BaseTooltipType } from '../ts/types/tooltip'

type TooltipProps = {
  tooltip: BaseTooltipType
  top: number
  left: number
  children: string | JSX.Element | JSX.Element[] | null
  theme: 'dark' | 'light'
}

export const StyledTooltip = ({
  tooltip,
  top,
  left,
  children,
  theme,
}: TooltipProps) => {
  const {
    minWidth,
    maxWidth,
    maxHeight,
    minHeight,
    width,
    background,
    border,
    padding,
    borderRadius,
    fontFamily,
    fontSize,
  } = tooltip.style
  return (
    <TooltipWithBounds
      className='tooltip with-bounds'
      top={top + tooltip.offsetY}
      left={left + tooltip.offsetX}
      style={{
        position: 'absolute',
        pointerEvents: 'none',
        width,
        minWidth,
        maxWidth,
        maxHeight,
        minHeight,
        overflow: 'auto',
        background: theme === 'light' ? background : '#1e1e1e',
        border: theme === 'light' ? border : '1px solid #fff',
        padding,
        borderRadius,
        fontFamily,
        fontSize,
        lineHeight: '1.2em',
        boxShadow: '0px 0px 2px 0px #63646480',
        zIndex: 9999,
      }}
    >
      {children}
    </TooltipWithBounds>
  )
}
