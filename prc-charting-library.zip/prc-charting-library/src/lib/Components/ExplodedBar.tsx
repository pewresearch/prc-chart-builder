import { useCallback, useContext, useMemo, useRef } from 'react'

import { DataContext } from '../Utilities/DataContext'
import { useSize, labelFill, scaleAxisNumTicks } from '../Utilities'
import {
  getChartDimensions,
  getLabelFormat,
  positionBarLabel,
  getTooltipFormat,
  getTooltipHeaderFormat,
  getSharedProps,
} from './shared'
import { StyledTooltip, StyledLegend, DiffColumn } from './index'
import type { FlatData } from '../ts/types/flatData'
import type { Size } from '../ts/types/windowSize'
import type { BaseConfig } from '../ts/types/configTypes'
import type { TableData } from '../ts/types/tableData'

import { BarStackHorizontal } from '@visx/shape'
import { Group } from '@visx/group'
import { GridRows, GridColumns } from '@visx/grid'
import { AxisBottom, AxisLeft } from '@visx/axis'
import { scaleLinear, scaleBand, scaleOrdinal } from '@visx/scale'
import { useTooltip } from '@visx/tooltip'
import { localPoint } from '@visx/event'
import { ascending, descending } from 'd3-array'
import { LegendOrdinal } from '@visx/legend'

const ExplodedBar = () => {
  const { data, config, tableData } = useContext(DataContext) as {
    data: any
    config: BaseConfig
    tableData: TableData
  }
  const {
    dependentAxis,
    independentAxis,
    layout,
    colors,
    dataRender,
    tooltip,
    labels,
    legend,
    explodedBar,
    bar,
    diffColumn,
  } = config

  // LAYOUT
  const { width, height, parentClass, padding, theme } = layout
  const svgRef = useRef<SVGSVGElement>(null)
  let size: Size = useSize(parentClass, svgRef)
  const { chartWidth, innerWidth, innerHeight } = getChartDimensions(
    size,
    layout,
    diffColumn,
  )
  let labelCutoff =
    size.width && size.width >= width
      ? labels.labelCutoff
      : labels.labelCutoffMobile

  let scaledNumTicks = useMemo(
    () => scaleAxisNumTicks(dependentAxis.tickCount || 5, chartWidth, width),
    [dependentAxis.tickCount, chartWidth, width],
  )
  // DATA PROCESSING
  const flattenedData = data.reduce((acc: string | any[], curr: any) => {
    return acc.concat(curr)
  }, [])

  flattenedData.sort((a: FlatData, b: FlatData) => {
    if (dataRender.sortOrder === 'ascending') {
      return ascending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    if (dataRender.sortOrder === 'descending') {
      return descending(a[dataRender.sortKey], b[dataRender.sortKey])
    }
    return 0
  })
  // this feels counterintuitive,
  // but we need to reverse the data because
  // d3 stacks the data from the bottom up.

  flattenedData.reverse()

  // DATA ACCESSORS
  const getIndependentValue = useCallback(
    (d: FlatData) => d[dataRender.x].toString(),
    [dataRender.x],
  )
  // SCALES, VORONOI, INTERPOLATION

  const independentScale = useMemo(
    () =>
      scaleBand<string>({
        domain: flattenedData.map(getIndependentValue),
        // TODO: abstract padding out into config
        padding: bar.barPadding,
      }),
    [flattenedData, getIndependentValue, bar.barPadding],
  )
  const dependentScale = useMemo(
    () =>
      scaleLinear({
        domain: dependentAxis.domain,
        range: [0, innerWidth / dataRender.categories.length - 30],
        nice: true,
      }),
    [innerWidth, dependentAxis.domain, dataRender.categories],
  )
  const colorScale = useMemo(
    () =>
      scaleOrdinal<string, string>({
        domain: dataRender.categories,
        range: colors,
      }),
    [dataRender.categories, colors],
  )
  dependentScale.rangeRound([0, innerWidth / dataRender.categories.length - 30])
  independentScale.rangeRound([innerHeight, 0])

  // GET SHARED LAYOUT PROPS
  const {
    dependentAxisProps,
    independentAxisProps,
    dependentGridProps,
    independentGridProps,
    ariaProps,
    legendProps,
    tooltipVisible,
    labelProps,
  } = useMemo(
    () =>
      getSharedProps({
        chartType: 'A exploded horizontal bar chart',
        config,
        data: flattenedData,
        size,
        tableData,
        dependentScale,
        independentScale,
      }),
    [config, flattenedData, size, tableData, dependentScale, independentScale],
  )

  // TOOLTIP AND HANDLERS
  const {
    tooltipData,
    tooltipLeft = 0,
    tooltipTop = 0,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip<FlatData>()

  let tooltipTimeout: number

  return (
    <div style={{ position: 'relative' }}>
      <svg width={chartWidth} height={height} ref={svgRef} {...ariaProps}>
        {dataRender.categories.map((category: string, i: number) => {
          return (
            <Group
              role='presentation'
              key={category}
              top={padding.top}
              left={
                // for left positioning, let's apply the desired left padding from the global config
                // and then the width of the chart times the index of the current category
                // and then add 16px of padding between each category
                padding.left +
                innerWidth * (i / dataRender.categories.length) +
                (i > 0 ? explodedBar.columnGap * i : 0)
              }
            >
              <GridRows {...independentGridProps} />
              <GridColumns {...dependentGridProps} />
              <BarStackHorizontal
                data={flattenedData}
                keys={[category]}
                height={innerHeight}
                y={getIndependentValue}
                xScale={dependentScale}
                yScale={independentScale}
                color={colorScale}
              >
                {barStacks => {
                  return barStacks.map(barStack =>
                    barStack.bars.map((bar, i) => {
                      const category = bar.key as string
                      const barData = bar.bar['data']
                      const barValue = barData[category as keyof typeof barData]
                      // check if there are custom labels or tooltips in the data model
                      const customLabel = flattenedData[i]['__labels']?.[
                        bar.key
                      ]
                        ? flattenedData[i]['__labels'][bar.key]
                        : ''
                      const customTooltip = flattenedData[i]['__tooltips']?.[
                        bar.key
                      ]
                        ? flattenedData[i]['__tooltips'][bar.key]
                        : ''
                      return (
                        <g
                          key={`barstack-horizontal-${barStack.index}-${bar.index}-g`}
                        >
                          <rect
                            key={`barstack-horizontal-${barStack.index}-${bar.index}`}
                            x={bar.x}
                            y={bar.y}
                            width={barValue ? Math.abs(bar.width) : 0}
                            height={bar.height}
                            fill={bar.color}
                            fillOpacity={
                              tooltipData &&
                              tooltipVisible &&
                              tooltip.deemphasizeSiblings &&
                              (tooltipData?.x !== barData.x ||
                                tooltipData?.y !== barValue ||
                                tooltipData?.category !== category)
                                ? tooltip.deemphasizeOpacity
                                : 1
                            }
                            onBlur={() => {
                              tooltipTimeout = window.setTimeout(() => {
                                hideTooltip()
                              }, 300)
                            }}
                            onFocus={() => {
                              if (tooltipTimeout) clearTimeout(tooltipTimeout)
                              showTooltip({
                                tooltipData: {
                                  x: barData.x,
                                  y: barValue,
                                  category,
                                  tooltip: customTooltip,
                                },
                                tooltipTop: bar.y,
                                tooltipLeft: bar.x,
                              })
                            }}
                            onMouseLeave={() => {
                              tooltipTimeout = window.setTimeout(() => {
                                hideTooltip()
                              }, 300)
                            }}
                            onMouseMove={event => {
                              if (tooltipTimeout) clearTimeout(tooltipTimeout)
                              const eventSvgCoords = localPoint(event) || {
                                x: 0,
                                y: 0,
                              }
                              showTooltip({
                                tooltipData: {
                                  x: barData.x,
                                  y: barValue,
                                  category,
                                  customTooltip,
                                },
                                tooltipTop: eventSvgCoords.y,
                                tooltipLeft: eventSvgCoords.x,
                              })
                            }}
                          />
                          {barValue && labels.active && (
                            <text
                              key={`barstack-horizontal-label-${barStack.index}-${bar.index}`}
                              {...labelProps}
                              {...positionBarLabel(
                                {
                                  x: bar.x,
                                  y: bar.y,
                                  width: bar.width,
                                  height: bar.height,
                                  value: barValue,
                                },
                                labels,
                                labelCutoff,
                                'horizontal',
                                'single',
                              )}
                              fill={
                                labels.labelPositionBar === 'outside' ||
                                barValue < labelCutoff
                                  ? theme === 'light'
                                    ? 'black'
                                    : 'white'
                                  : labelFill(bar.color)
                              }
                              fillOpacity={
                                tooltipData &&
                                tooltipVisible &&
                                tooltip.deemphasizeSiblings &&
                                (tooltipData?.x !== barData.x ||
                                  tooltipData?.y !== barValue ||
                                  tooltipData?.category !== category)
                                  ? tooltip.deemphasizeOpacity
                                  : 1
                              }
                            >
                              {customLabel
                                ? customLabel
                                : `${getLabelFormat(
                                    barValue,
                                    category,
                                    labels,
                                    null,
                                  )}`}
                            </text>
                          )}
                        </g>
                      )
                    }),
                  )
                }}
              </BarStackHorizontal>
              {diffColumn.active && diffColumn.category && (
                <DiffColumn
                  diffColumn={diffColumn}
                  innerHeight={innerHeight}
                  innerWidth={innerWidth}
                  flattenedData={flattenedData}
                  scale={independentScale}
                  dataRender={dataRender}
                  labels={labels}
                  layout={layout}
                />
              )}
              {independentAxis.active && i === 0 && (
                <AxisLeft
                  {...independentAxisProps}
                  tickValues={flattenedData.map(getIndependentValue)}
                  scale={independentScale}
                  numTicks={flattenedData.length}
                />
              )}
              {dependentAxis.active && (
                <AxisBottom
                  {...dependentAxisProps}
                  top={innerHeight}
                  scale={dependentScale}
                  numTicks={scaledNumTicks}
                />
              )}
            </Group>
          )
        })}
      </svg>
      {legend.active && (
        <StyledLegend legend={legend} theme={theme}>
          <LegendOrdinal
            {...legendProps}
            scale={colorScale}
            domain={
              legend.categories.length > 0
                ? legend.categories
                : colorScale.domain()
            }
          />
        </StyledLegend>
      )}
      {tooltipOpen && tooltipData && tooltipVisible && (
        <StyledTooltip
          top={tooltipTop}
          left={tooltipLeft}
          tooltip={tooltip}
          theme={theme}
        >
          <>
            {tooltip.headerActive && (
              <div
                style={{
                  marginBottom: '10px',
                }}
              >
                <strong>
                  {getTooltipHeaderFormat(
                    {
                      x: tooltipData.x,
                      category: tooltipData.key,
                    },
                    tooltip,
                  )}
                </strong>
              </div>
            )}
          </>
          <div
            dangerouslySetInnerHTML={{
              __html: tooltipData.tooltip
                ? tooltipData.tooltip
                : getTooltipFormat(
                    {
                      y: tooltipData.y,
                      x: tooltipData.x,
                      category: tooltipData.category,
                      color: colorScale(tooltipData.category || ''),
                    },
                    tooltip,
                    dataRender,
                  ),
            }}
          />
        </StyledTooltip>
      )}
    </div>
  )
}

export default ExplodedBar
