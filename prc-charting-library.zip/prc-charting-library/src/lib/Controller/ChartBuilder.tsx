// React Dependencies
import { useContext } from 'react'
// External Dependencies
import styled from 'styled-components'
// Internal Dependencies
import { DataContext } from '../Utilities/DataContext'
import {
  BarHorizontal,
  BarVertical,
  DivergingBarHorizontal,
  DivergingBarVertical,
  DotPlot,
  ExplodedBar,
  Line,
  Pie,
  Scatter,
  StackedBarHorizontal,
  StackedBarVertical,
  StackedArea,
} from '../Components'

import {
  AlbersUSA,
  AlbersUSACounties,
  BlockUSA,
  World,
} from '../Components/maps'

import CustomChartRenderer from '../Components/custom'

const ChartContainer = styled.div<{ maxWidth: number; maxHeight: number }>`
  max-width: ${props => props.maxWidth}px;
  max-height: ${props => props.maxHeight}px;
  width: 100%;
  height: auto;
`

const CustomChartContainer = styled.div<{
  maxWidth: number
  maxHeight: number
  unsetMaxHeight?: boolean
}>`
  max-width: 100%;
  max-height: ${props =>
    props.unsetMaxHeight ? 'none' : `${props.maxHeight}px`};
  width: 100%;
  height: auto;
`

const ChartBuilder = () => {
  const { config } = useContext(DataContext)
  const { type, orientation, width, height } = config.layout
  if (true === config.custom.isCustomChart) {
    return (
      <CustomChartContainer
        className='cb__chart cb__chart__custom'
        maxWidth={width}
        maxHeight={height}
        unsetMaxHeight={config.custom.attributes.unsetMaxHeight}
      >
        <CustomChartRenderer {...config.custom} />
      </CustomChartContainer>
    )
  } else {
    switch (type) {
      case 'bar':
        if (orientation === 'vertical') {
          return (
            <ChartContainer
              className='cb__chart cb__chart__bar--vertical'
              maxWidth={width}
              maxHeight={height}
            >
              <BarVertical />
            </ChartContainer>
          )
        } else {
          return (
            <ChartContainer
              className='cb__chart cb__chart__bar--horizontal'
              maxWidth={width}
              maxHeight={height}
            >
              <BarHorizontal />
            </ChartContainer>
          )
        }
      case 'pie':
        return (
          <ChartContainer
            className='cb__chart cb__chart__pie'
            maxWidth={width}
            maxHeight={height}
          >
            <Pie />
          </ChartContainer>
        )
      case 'stacked-bar':
        if (orientation === 'vertical') {
          return (
            <ChartContainer
              className='cb__chart cb__chart__stacked-bar--vertical'
              maxWidth={width}
              maxHeight={height}
            >
              <StackedBarVertical />
            </ChartContainer>
          )
        } else {
          return (
            <ChartContainer
              className='cb__chart cb__chart__stacked-bar--horizontal'
              maxWidth={width}
              maxHeight={height}
            >
              <StackedBarHorizontal />
            </ChartContainer>
          )
        }
      case 'diverging-bar':
        if (orientation === 'vertical') {
          return (
            <ChartContainer
              className='cb__chart cb__chart__diverging-bar--vertical'
              maxWidth={width}
              maxHeight={height}
            >
              <DivergingBarVertical />
            </ChartContainer>
          )
        } else {
          return (
            <ChartContainer
              className='cb__chart cb__chart__diverging-bar--horizontal'
              maxWidth={width}
              maxHeight={height}
            >
              <DivergingBarHorizontal />
            </ChartContainer>
          )
        }
      case 'exploded-bar':
        return (
          <ChartContainer
            className='cb__chart cb__chart__exploded-bar'
            maxWidth={width}
            maxHeight={height}
          >
            <ExplodedBar />
          </ChartContainer>
        )
      case 'line':
        return (
          <ChartContainer
            className='cb__chart cb__chart__line'
            maxWidth={width}
            maxHeight={height}
          >
            <Line />
          </ChartContainer>
        )
      case 'stacked-area':
        return (
          <ChartContainer
            className='cb__chart cb__chart__stacked-area'
            maxWidth={width}
            maxHeight={height}
          >
            <StackedArea />
          </ChartContainer>
        )
      case 'dot-plot':
        return (
          <ChartContainer
            className='cb__chart cb__chart__dot-plot'
            maxWidth={width}
            maxHeight={height}
          >
            <DotPlot />
          </ChartContainer>
        )
      case 'scatter':
        return (
          <ChartContainer
            className='cb__chart cb__chart__scatter'
            maxWidth={width}
            maxHeight={height}
          >
            <Scatter />
          </ChartContainer>
        )
      case 'map-usa':
        return (
          <ChartContainer
            className='cb__chart cb__chart__map-usa'
            maxWidth={width}
            maxHeight={height}
          >
            <AlbersUSA />
          </ChartContainer>
        )
      case 'map-usa-counties':
        return (
          <ChartContainer
            className='cb__chart cb__chart__map-usa-counties'
            maxWidth={width}
            maxHeight={height}
          >
            <AlbersUSACounties />
          </ChartContainer>
        )
      case 'map-usa-block':
        return (
          <ChartContainer
            className='cb__chart cb__chart__map-usa-block'
            maxWidth={width}
            maxHeight={height}
          >
            <BlockUSA />
          </ChartContainer>
        )
      case 'map-world':
        return (
          <ChartContainer
            className='cb__chart cb__chart__map-world'
            maxWidth={width}
            maxHeight={height}
          >
            <World />
          </ChartContainer>
        )
      default:
        return (
          <ChartContainer
            className='cb__chart cb__chart__line'
            maxWidth={width}
            maxHeight={height}
          >
            <Line />
          </ChartContainer>
        )
    }
  }
}

export default ChartBuilder
