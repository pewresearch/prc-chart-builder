// External dependencies
import { ErrorBoundary } from 'react-error-boundary'

// Internal dependencies
import ChartBuilder from './ChartBuilder'
import { DataProvider } from '../Utilities/DataContext'
// Types
import { BaseConfig } from '../ts/types/configTypes'
import { TableData } from '../ts/types/tableData'
// import useDarkMode from '../Utilities/useDarkMode';

type WrapperProps = {
  data: any
  config: BaseConfig
  tableData?: TableData
  fallbackImg?: string
  // onClick: (event: any, data: any) => void
}
function ErrorFallback(props: any) {
  const { error, fallbackImg } = props
  console.log({ 'Error:': error.message })
  return (
    <>
      {fallbackImg && (
        <img
          src={fallbackImg}
          alt='fallback'
          style={{ width: '100%', height: 'auto' }}
        />
      )}
      {!fallbackImg && (
        <div role='alert'>
          <p>This chart is currently unavailable. Please try again later</p>
        </div>
      )}
    </>
  )
}

const ChartBuilderWrapper = ({
  data,
  config,
  tableData,
  fallbackImg,
}: WrapperProps) => {
  // sanitize data model here
  // const [darkMode] = useDarkMode();
  // TODO: add fallback img to view.js for chart-builder
  return (
    // @ts-ignore
    <DataProvider
      value={{
        data: data,
        config,
        tableData,
        // onClick,
      }}
    >
      <ErrorBoundary
        FallbackComponent={props => (
          <ErrorFallback {...props} fallbackImg={fallbackImg} />
        )}
      >
        <ChartBuilder />
      </ErrorBoundary>
    </DataProvider>
  )
}

export default ChartBuilderWrapper
