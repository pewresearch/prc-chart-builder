// React Dependencies
import { createRoot } from 'react-dom/client'
// Internal Dependencies
import ChartBuilderWrapper from './ChartBuilderWrapper'
import ChartBuilderTextWrapper from './ChartBuilderTextWrapper'
// Types
import { BaseConfig } from '../ts/types/configTypes'
import { TableData } from '../ts/types/tableData'

// render component for ChartBuilderWrapper.
// requires id, data, and config props
// id: string
// data: any
// config: BaseConfig

const ChartBuilderRenderer = (
  id: string,
  data: any,
  config: BaseConfig,
  tableData: TableData,
) => {
  const root = document.getElementById(id)
  if (root) {
    createRoot(root).render(
      <>
        <ChartBuilderWrapper
          data={data}
          config={config}
          tableData={tableData}
        />
      </>,
    )
  }
}

export default ChartBuilderRenderer
