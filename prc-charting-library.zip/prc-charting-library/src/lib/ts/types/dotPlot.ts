export type DotPlot = {
  connectPoints: boolean;
  connectingLine: {
    strokeWidth: number;
    stroke: string;
    strokeOpacity: number;
    strokeDasharray: string;
  };
};
