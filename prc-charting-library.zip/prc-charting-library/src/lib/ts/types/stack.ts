export type Stack = {
  offset: 'expand' | 'diverging' | 'none' | 'silhouette' | 'wiggle';
};
