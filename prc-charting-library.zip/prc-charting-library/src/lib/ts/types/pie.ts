export type Pie = {
  showCategoryLabels: boolean
  hasPathStroke: boolean
  pathStrokeWidth: number
  pathStrokeColor: string
}
