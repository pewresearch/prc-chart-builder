export type Size = {
  width: number | undefined;
  height: number | undefined;
};
