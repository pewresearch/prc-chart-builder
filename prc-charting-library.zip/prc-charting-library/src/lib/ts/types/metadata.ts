export type Metadata = {
  active: boolean;
  title: string;
  subtitle: string;
  note: string;
  source: string;
  tag: string;
};
