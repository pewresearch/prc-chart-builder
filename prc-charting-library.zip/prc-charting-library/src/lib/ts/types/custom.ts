export type Custom = {
  isCustomChart: boolean
  attributes: {
    chartType: string | null
    [key: string]: any
  }
}
