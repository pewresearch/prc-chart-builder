export type Keys = {
  [key: string]: string;
};
