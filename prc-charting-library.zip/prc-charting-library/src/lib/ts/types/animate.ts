export type Animate = {
  active: boolean;
  animationWhitelist?: string[];
  duration?: number; //time in ms
};
