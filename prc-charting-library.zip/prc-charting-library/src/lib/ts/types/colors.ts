export type Colors = string[];
