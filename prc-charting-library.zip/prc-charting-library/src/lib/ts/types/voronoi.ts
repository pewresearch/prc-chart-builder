export type Voronoi = {
  active: boolean;
  fill: string;
  stroke: string;
  strokeWidth: number;
  strokeOpacity: number;
};
