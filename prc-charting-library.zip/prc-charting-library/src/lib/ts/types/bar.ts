export type Bar = {
  hasRectStroke: boolean
  rectStrokeWidth: number
  rectStrokeColor: string
  barGroupPadding: number
  barPadding: number
  groupBreaksActive: boolean
  groupBreaks: {
    labelsActive: boolean
    values: any[]
    labels: any[]
    breakStyles: {
      variation: 'empty' | 'solid' | 'dotted' | 'dashed' | 'heartbeat'
      stroke: string
      strokeWidth: number
      height: number
      strokeDasharray: string
    }
    labelStyles: {
      fill: string
      fontStyle: 'normal' | 'italic' | 'bold'
    }
  }
}
