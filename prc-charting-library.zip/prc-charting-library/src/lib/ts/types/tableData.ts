export type TableData = {
  header: string[]
  rows: string[][]
  footer?: string[]
}
