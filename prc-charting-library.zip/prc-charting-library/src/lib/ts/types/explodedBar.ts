export type ExplodedBar = {
  columnGap: number
}
