export type Legend = {
  active: boolean
  orientation: 'row' | 'column' | 'row-reverse' | 'column-reverse'
  title: string
  offsetX: number
  offsetY: number
  alignment: 'flex-start' | 'flex-end' | 'center' | 'none'
  markerStyle: 'rect' | 'circle' | 'line'
  borderStroke: string
  fill: string
  categories: string[]
  labelDelimiter: string
  labelLower: string
  labelUpper: string
}
