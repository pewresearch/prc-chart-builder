# Pew Research Center's Chart Builder 📈
A charting library for the Pew Research Center, powered by VisX.

## Building and adding to PRC Scripts

After much consideration, we’ve decided to remove the chart builder package from it’s former home as a private NPM package and instead home the entire codebase within the prc-scripts plugin. While we’re migrating, the short-term build process is as such:

After making any updates, run:

```jsx
npm run build && npm pack
```

This will create a gzipped version of the library. Then move the gzip to prc-scripts:

```jsx
mv pewresearch/chart-builder-{version}.tgz ~/path/to/pewresearch-org/plugins/prc-scripts/src/@prc/chart-builder/
cd ~/path/to/pewresearch-org/plugins/prc-scripts/src/@prc/chart-builder/
npm install && npm run build
```

## Config

For full chart config examples, see [the configuration table](https://www.notion.so/Chart-Builder-Config-4731c3ecd6fb4e6494d569fe36184ebd)
