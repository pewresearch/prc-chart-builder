const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');

// WIP: This script will be for packaging chart builder for as a standalone fully packaged plugin with no dependencies (remove requires-plugin header and bundles prc-scripts in output.

try {
	console.log('Packaging Chart Builder for .org Release...');

	// get version number from package.json
	const version = require('../package.json').version;

	// create a zip file with the version number
	const zipPath = path.join(__dirname, `../chart-builder-${version}.zip`);

	// change to parent directory
	process.chdir(path.join(__dirname, '..'));

	// remove existing zip if it exists
	if (fs.existsSync(zipPath)) {
		fs.unlinkSync(zipPath);
	}

	// remove any zip files in the root directory
	fs.readdirSync(__dirname).forEach((file) => {
		if (file.endsWith('.zip')) {
			fs.unlinkSync(path.join(__dirname, file));
		}
	});

	// install all dependencies
	console.log('Installing dependencies...');
	execSync('npm install', { stdio: 'inherit' });

	// build the plugin
	console.log('Building plugin...');
	execSync('npm run build', { stdio: 'inherit' });

	// compress specific plugin files into a zip file
	console.log('Creating zip file...');
	execSync(
		`zip -r ${zipPath} build .shared .scripts src *.php *.txt package.json README.md`,
		{
			stdio: 'inherit',
		}
	);

	console.log(`Package compressed and saved to ${zipPath}`);
} catch (error) {
	console.error('Error packaging Chart Builder:', error);
	process.exit(1);
}
