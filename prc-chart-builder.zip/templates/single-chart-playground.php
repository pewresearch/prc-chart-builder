
<!-- wp:group {"tagName":"article","className":"centered","layout":{"type":"constrained","contentSize":"640px"}} -->
<article class="wp-block-group centered"><!-- wp:template-part {"slug":"post-meta","area":"uncategorized","theme":"prc-design-system"} /-->

<!-- wp:post-title {"level":1,"fontSize":"h1"} /--></article>
<!-- /wp:group -->

<!-- wp:post-content {"layout":{"type":"constrained","contentSize":"640px","wideSize":"1200px"}} /-->
